create table if not exists price_ticks (
  id text primary key,
  source text not null,
  symbol text not null default 'USDT',
  price_toman integer not null,
  captured_at timestamptz not null default now()
);
create index if not exists price_ticks_captured_idx on price_ticks (captured_at desc);

create table if not exists job_runs (
  id text primary key,
  started_at timestamptz not null default now(),
  status text not null,
  reason text,
  source text,
  price_toman integer,
  delta_toman integer,
  slot text,
  sms_status text,
  logs_json text not null default '[]'
);
create index if not exists job_runs_started_idx on job_runs (started_at desc);

create table if not exists daily_quota (
  day_key text primary key,
  sent_count integer not null default 0,
  slots_sent text not null default '[]',
  last_price_toman integer,
  last_message_hash text
);

create table if not exists engine_state (
  id text primary key,
  last_price_toman integer,
  last_sent_at timestamptz,
  updated_at timestamptz not null default now()
);
