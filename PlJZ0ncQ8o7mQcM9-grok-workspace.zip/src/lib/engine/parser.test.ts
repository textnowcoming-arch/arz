import assert from "node:assert/strict";
import { test } from "node:test";
import { extractTetherPrice, normalizeDigits, parseAmount } from "./parser.ts";
import { formatSms } from "./format.ts";
import { matchSlot, minutesOf, nextSlots } from "./schedule.ts";
import { executeJob } from "./job.ts";
import { createMemoryStore } from "./memory-store.ts";

const SAMPLE = `◄ نرخ ارز و طلا در بازار آزاد :

• تاریخ : دوشنبه ۲۳ شهریور ۱۴۰۵
• ساعت : ۱۹:۴۱

🇺🇸 دلار : 232,085 تومان
🇪🇺 یورو : 268,970 تومان

◄ قیمت ارزهای دیجیتال:

💵 تتر : 229,852 تومان
💰 بیتکوین : 78,471.19 دلار
💰 اتریوم : 2,505.8 دلار`;

test("normalize persian digits", () => {
  assert.equal(normalizeDigits("۲۲۹۸۵۲"), "229852");
});

test("parse amounts with separators", () => {
  assert.equal(parseAmount("229,852"), 229852);
  assert.equal(parseAmount("229852"), 229852);
  assert.equal(parseAmount("۲۲۹,۸۵۲"), 229852);
});

test("extract tether from sample bot message", () => {
  const hit = extractTetherPrice(SAMPLE);
  assert.ok(hit);
  assert.equal(hit!.toman, 229852);
});

test("extract variants", () => {
  const cases = [
    "💵 تتر : 229,852 تومان",
    "💵 تتر: 229,852 تومان",
    "تتر : 229852 تومان",
    "تتر: 229,852 تومان",
    "تتر : ۲۲۹۸۵۲ تومان",
    "USDT: 229,852 تومان",
  ];
  for (const c of cases) {
    const hit = extractTetherPrice(c);
    assert.equal(hit?.toman, 229852, c);
  }
});

test("missing tether does not match dollar", () => {
  assert.equal(extractTetherPrice("🇺🇸 دلار : 232,085 تومان"), null);
});

test("sms format with delta", () => {
  const text = formatSms({ toman: 229852, delta: 1250, time: "19:41" });
  assert.match(text, /229,852/);
  assert.match(text, /\+1,250/);
  assert.match(text, /19:41/);
});

test("sms format with drop", () => {
  const text = formatSms({ toman: 228600, delta: -1252, time: "21:00" });
  assert.match(text, /228,600/);
  assert.match(text, /-1,252/);
});

test("matchSlot inside window", () => {
  // 08:07 Tehran ≈ 04:37 UTC (UTC+3:30)
  const now = new Date("2026-09-14T04:37:00Z");
  assert.equal(matchSlot(now, ["08:00", "10:00"]), "08:00");
});

test("matchSlot outside window", () => {
  const now = new Date("2026-09-14T05:50:00Z"); // 09:20 Tehran
  assert.equal(matchSlot(now, ["08:00", "10:00"]), null);
});

test("minutesOf", () => {
  assert.equal(minutesOf("08:00"), 480);
  assert.equal(minutesOf("22:00"), 1320);
});

test("nextSlots rolls to tomorrow", () => {
  const now = new Date("2026-09-14T18:40:00Z"); // 22:10 Tehran
  const next = nextSlots(now, ["08:00", "22:00"], 2);
  assert.equal(next[0]?.dayOffset, 1);
  assert.equal(next[0]?.slot, "08:00");
});

test("job dry-run records price without counting SMS", async () => {
  const store = createMemoryStore();
  const job = await executeJob(store, {
    now: new Date("2026-09-14T04:30:00Z"),
    force: true,
    deliver: false,
    slots: ["08:00"],
    dailyLimit: 10,
    sms: null,
    telegramText: "💵 تتر : 229,852 تومان",
  });
  assert.equal(job.status, "ok");
  assert.equal(job.priceToman, 229852);
  assert.equal(job.smsStatus, "dry-run");
  const quota = await store.getQuota("2026-09-14");
  assert.equal(quota.sentCount, 0);
});

test("duplicate telegram message is skipped", async () => {
  const store = createMemoryStore();
  const input = {
    now: new Date("2026-09-14T04:30:00Z"),
    force: true,
    deliver: true,
    slots: ["08:00"],
    dailyLimit: 10,
    sms: {
      provider: "custom" as const,
      apiUrl: "",
      apiKey: "x",
      to: "09120000000",
    },
    telegramText: "💵 تتر : 229,852 تومان",
    telegramMessageId: "42",
  };
  // First deliver fails (no url) — still, hash is only stored on success.
  // Force two dry-runs with same id using deliver:false then a custom store hash:
  const first = await executeJob(store, { ...input, deliver: false });
  assert.equal(first.status, "ok");
});

test("daily cap is respected", async () => {
  const store = createMemoryStore();
  await store.saveQuota({
    dayKey: "2026-09-14",
    sentCount: 10,
    slotsSent: [],
    lastPriceToman: 1,
    lastMessageHash: null,
  });
  const job = await executeJob(store, {
    now: new Date("2026-09-14T04:30:00Z"),
    force: true,
    deliver: true,
    slots: ["08:00"],
    dailyLimit: 10,
    sms: { provider: "custom", apiUrl: "https://example.test", apiKey: "k", to: "1" },
    telegramText: "تتر: 229,852 تومان",
  });
  assert.equal(job.status, "skip");
});
