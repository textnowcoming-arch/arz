export function formatToman(n: number): string {
  return Math.round(n).toLocaleString("en-US");
}

export function formatSms(opts: {
  toman: number;
  delta?: number | null;
  time: string;
}): string {
  const lines = [`💵 تتر: ${formatToman(opts.toman)} تومان`];
  if (opts.delta != null && opts.delta !== 0) {
    const up = opts.delta > 0;
    const arrow = up ? "📈" : "📉";
    const sign = up ? "+" : "-";
    lines.push(`${arrow} ${sign}${formatToman(Math.abs(opts.delta))} تومان`);
  }
  lines.push(`🕐 ${opts.time}`);
  return lines.join("\n");
}

export async function sha256hex(value: string): Promise<string> {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `id_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
