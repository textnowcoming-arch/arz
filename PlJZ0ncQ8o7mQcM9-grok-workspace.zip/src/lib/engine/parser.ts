const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
const AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";

export function normalizeDigits(input: string): string {
  let out = "";
  for (const ch of input) {
    const fa = FA_DIGITS.indexOf(ch);
    if (fa >= 0) {
      out += String(fa);
      continue;
    }
    const ar = AR_DIGITS.indexOf(ch);
    if (ar >= 0) {
      out += String(ar);
      continue;
    }
    out += ch;
  }
  return out;
}

/** Strip thousand separators; keep a trailing decimal only if it looks like cents. */
export function parseAmount(raw: string): number | null {
  const normalized = normalizeDigits(raw)
    .replace(/[٬،\s]/g, "")
    .replace(/,/g, "")
    .trim();
  if (!normalized) return null;

  // 229.852 or 229852.00 — drop a 3-digit grouping dot, keep 1–2 decimal cents
  let cleaned = normalized;
  if (/^\d{1,3}(\.\d{3})+$/.test(cleaned)) {
    cleaned = cleaned.replace(/\./g, "");
  } else if (/^\d+\.\d{3,}$/.test(cleaned)) {
    cleaned = cleaned.replace(/\./g, "");
  }

  if (!/^\d+(\.\d+)?$/.test(cleaned)) return null;
  const value = Number(cleaned);
  if (!Number.isFinite(value) || value <= 0) return null;
  return Math.round(value);
}

const TETHER_PATTERNS: RegExp[] = [
  /(?:💵|💲)?\s*تتر(?:\s*\(?\s*usdt\s*\)?)?\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال)?/i,
  /(?:قیمت\s*)?تتر\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال)?/i,
  /\busdt\b\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال|toman)?/i,
  /\btether\b\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال|toman)?/i,
];

export type ParseHit = {
  toman: number;
  matched: string;
  unit: "toman" | "rial";
};

const TOMAN_MIN = 1_000;
const TOMAN_MAX = 20_000_000;

export function extractTetherPrice(text: string): ParseHit | null {
  if (!text || typeof text !== "string") return null;
  const haystack = normalizeDigits(text).replace(/\u200c/g, " ");

  for (const pattern of TETHER_PATTERNS) {
    const copy = new RegExp(pattern.source, pattern.flags);
    const match = copy.exec(haystack);
    if (!match?.[1]) continue;
    const amount = parseAmount(match[1]);
    if (amount == null) continue;

    const unitRaw = (match[2] ?? "").toLowerCase();
    let toman = amount;
    let unit: "toman" | "rial" = "toman";

    if (unitRaw === "ریال" || (amount >= 1_000_000 && amount % 10 === 0)) {
      // TGJU-style rial quotes are ~10× toman. Only convert when the number
      // is clearly in rial territory or the unit says so.
      if (unitRaw === "ریال" || amount >= 1_000_000) {
        toman = Math.round(amount / 10);
        unit = "rial";
      }
    }

    if (toman < TOMAN_MIN || toman > TOMAN_MAX) continue;
    return { toman, matched: match[0].trim(), unit };
  }

  return null;
}

export function isValidTomanPrice(n: number): boolean {
  return Number.isInteger(n) && n >= TOMAN_MIN && n <= TOMAN_MAX;
}
