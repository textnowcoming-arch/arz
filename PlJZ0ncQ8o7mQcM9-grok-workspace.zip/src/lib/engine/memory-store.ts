import type { EngineState, JobRun, QuotaState, StateStore } from "./types.ts";

export function emptyQuota(dayKey: string): QuotaState {
  return {
    dayKey,
    sentCount: 0,
    slotsSent: [],
    lastPriceToman: null,
    lastMessageHash: null,
  };
}

export function createMemoryStore(): StateStore {
  const quotas = new Map<string, QuotaState>();
  let engine: EngineState = { lastPriceToman: null, lastSentAt: null };
  const jobs: JobRun[] = [];
  const ticks: { capturedAt: string; priceToman: number; source: string }[] = [];

  return {
    async getQuota(dayKey) {
      return quotas.get(dayKey) ?? emptyQuota(dayKey);
    },
    async saveQuota(q) {
      quotas.set(q.dayKey, { ...q, slotsSent: [...q.slotsSent] });
    },
    async getEngineState() {
      return { ...engine };
    },
    async saveEngineState(s) {
      engine = { ...s };
    },
    async recordJob(job) {
      jobs.unshift(job);
      if (jobs.length > 200) jobs.pop();
    },
    async recordTick(tick) {
      ticks.unshift({
        capturedAt: tick.capturedAt,
        priceToman: tick.priceToman,
        source: tick.source,
      });
      if (ticks.length > 400) ticks.pop();
    },
    async recentJobs(limit) {
      return jobs.slice(0, limit);
    },
    async recentTicks(limit) {
      return ticks.slice(0, limit);
    },
  };
}
