import type { SmsConfig } from "./types.ts";

export type SmsSendResult =
  | { ok: true; provider: string }
  | { ok: false; error: string };

function mask(value: string): string {
  if (!value) return "";
  if (value.length <= 4) return "••••";
  return `${value.slice(0, 2)}•••${value.slice(-2)}`;
}

export function redactSmsConfig(cfg: SmsConfig): Record<string, string> {
  return {
    provider: cfg.provider,
    apiUrl: cfg.apiUrl,
    apiKey: mask(cfg.apiKey),
    to: mask(cfg.to),
  };
}

async function timedFetch(url: string, init: RequestInit, ms = 10000): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

export async function sendSms(cfg: SmsConfig, text: string): Promise<SmsSendResult> {
  if (!cfg.to.trim()) return { ok: false, error: "شماره گیرنده خالی است" };
  if (!text.trim()) return { ok: false, error: "متن پیامک خالی است" };

  try {
    if (cfg.provider === "kavenegar") {
      const key = cfg.apiKey.trim();
      if (!key) return { ok: false, error: "کلید کاوه‌نگار خالی است" };
      const base =
        cfg.apiUrl.trim() ||
        `https://api.kavenegar.com/v1/${encodeURIComponent(key)}/sms/send.json`;
      const url = new URL(base);
      url.searchParams.set("receptor", cfg.to);
      url.searchParams.set("message", text);
      const res = await timedFetch(url.toString(), { method: "GET" });
      if (!res.ok) return { ok: false, error: `SMS HTTP ${res.status}` };
      return { ok: true, provider: "kavenegar" };
    }

    if (cfg.provider === "melipayamak") {
      const url = cfg.apiUrl.trim() || "https://rest.payamak-panel.com/api/SendSMS/SendSMS";
      const res = await timedFetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: cfg.username ?? cfg.from ?? "",
          password: cfg.apiKey,
          to: cfg.to,
          from: cfg.from ?? "",
          text,
        }),
      });
      if (!res.ok) return { ok: false, error: `SMS HTTP ${res.status}` };
      return { ok: true, provider: "melipayamak" };
    }

    if (cfg.provider === "smsir") {
      const url = cfg.apiUrl.trim() || "https://api.sms.ir/v1/send/bulk";
      const res = await timedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-KEY": cfg.apiKey,
        },
        body: JSON.stringify({
          lineNumber: cfg.from ?? "",
          messageText: text,
          mobiles: [cfg.to],
        }),
      });
      if (!res.ok) return { ok: false, error: `SMS HTTP ${res.status}` };
      return { ok: true, provider: "smsir" };
    }

    const url = cfg.apiUrl.trim();
    if (!url) return { ok: false, error: "آدرس API پیامک تنظیم نشده" };
    const res = await timedFetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {}),
      },
      body: JSON.stringify({ to: cfg.to, message: text, from: cfg.from ?? "" }),
    });
    if (!res.ok) return { ok: false, error: `SMS HTTP ${res.status}` };
    return { ok: true, provider: "custom" };
  } catch (err) {
    const name = err instanceof Error ? err.name : "";
    if (name === "AbortError") return { ok: false, error: "SMS timeout" };
    return { ok: false, error: "ارسال پیامک ناموفق بود" };
  }
}

export function smsFromEnv(env: Record<string, string | undefined>): SmsConfig | null {
  const to = env.SMS_TO?.trim();
  const key = env.SMS_API_KEY?.trim();
  if (!to || !key) return null;
  const provider = (env.SMS_PROVIDER?.trim() || "custom") as SmsConfig["provider"];
  return {
    provider: ["kavenegar", "melipayamak", "smsir", "custom"].includes(provider)
      ? provider
      : "custom",
    apiUrl: env.SMS_API_URL?.trim() ?? "",
    apiKey: key,
    to,
    from: env.SMS_FROM?.trim(),
    username: env.SMS_USERNAME?.trim(),
  };
}
