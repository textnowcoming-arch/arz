export type JobStatus = "ok" | "skip" | "error";
export type SmsStatus = "dry-run" | "sent" | "skipped" | "failed" | "not-configured";

export type LogLine = {
  t: string;
  msg: string;
};

export type MarketQuote = {
  symbol: string;
  title: string;
  toman: number;
  change: number | null;
  changePct: number | null;
  capturedAt: string;
  sourceTime: string | null;
};

export type MarketSnapshot = {
  ok: true;
  source: "tgju";
  fetchedAt: string;
  tether: MarketQuote;
  dollar: MarketQuote | null;
  euro: MarketQuote | null;
  bitcoinUsd: number | null;
  ethereumUsd: number | null;
};

export type MarketError = {
  ok: false;
  error: string;
};

export type MarketResult = MarketSnapshot | MarketError;

export type QuotaState = {
  dayKey: string;
  sentCount: number;
  slotsSent: string[];
  lastPriceToman: number | null;
  lastMessageHash: string | null;
};

export type EngineState = {
  lastPriceToman: number | null;
  lastSentAt: string | null;
};

export type JobRun = {
  id: string;
  startedAt: string;
  status: JobStatus;
  reason: string | null;
  source: string | null;
  priceToman: number | null;
  deltaToman: number | null;
  slot: string | null;
  smsStatus: SmsStatus | null;
  logs: LogLine[];
  smsText: string | null;
};

export type SmsProvider = "kavenegar" | "melipayamak" | "smsir" | "custom";

export type SmsConfig = {
  provider: SmsProvider;
  apiUrl: string;
  apiKey: string;
  to: string;
  from?: string;
  username?: string;
};

export type JobInput = {
  now: Date;
  force: boolean;
  deliver: boolean;
  slots: string[];
  dailyLimit: number;
  sms: SmsConfig | null;
  telegramText?: string;
  telegramMessageId?: string;
};

export interface StateStore {
  getQuota(dayKey: string): Promise<QuotaState>;
  saveQuota(q: QuotaState): Promise<void>;
  getEngineState(): Promise<EngineState>;
  saveEngineState(s: EngineState): Promise<void>;
  recordJob(job: JobRun): Promise<void>;
  recordTick(tick: {
    id: string;
    source: string;
    symbol: string;
    priceToman: number;
    capturedAt: string;
  }): Promise<void>;
  recentJobs(limit: number): Promise<JobRun[]>;
  recentTicks(limit: number): Promise<
    { capturedAt: string; priceToman: number; source: string }[]
  >;
}
