import { formatSms, newId, sha256hex } from "./format.ts";
import { extractTetherPrice, isValidTomanPrice } from "./parser.ts";
import { matchSlot, tehranClock, tehranParts } from "./schedule.ts";
import { sendSms } from "./sms.ts";
import { fetchMarket } from "./sources.ts";
import type { JobInput, JobRun, LogLine, StateStore } from "./types.ts";

function clockLine(): string {
  return tehranClock();
}

function log(lines: LogLine[], msg: string) {
  lines.push({ t: clockLine(), msg });
}

export async function executeJob(
  store: StateStore,
  input: JobInput,
): Promise<JobRun> {
  const logs: LogLine[] = [];
  const id = newId();
  const startedAt = input.now.toISOString();
  const parts = tehranParts(input.now);
  log(logs, "Job started");

  const finish = (
    patch: Partial<JobRun> & Pick<JobRun, "status">,
  ): JobRun => ({
    id,
    startedAt,
    reason: null,
    source: null,
    priceToman: null,
    deltaToman: null,
    slot: null,
    smsStatus: null,
    smsText: null,
    logs,
    ...patch,
  });

  try {
    const quota = await store.getQuota(parts.dayKey);
    const engine = await store.getEngineState();
    const slot = input.force
      ? `manual-${parts.hhmm}`
      : matchSlot(input.now, input.slots);

    if (!input.force && !slot) {
      log(logs, "Outside schedule window — skip");
      const job = finish({
        status: "skip",
        reason: "خارج از پنجره زمان‌بندی",
        smsStatus: "skipped",
      });
      await store.recordJob(job);
      return job;
    }

    if (!input.force && slot && quota.slotsSent.includes(slot)) {
      log(logs, `Slot ${slot} already sent today — skip`);
      const job = finish({
        status: "skip",
        reason: "این نوبت امروز ارسال شده",
        slot,
        smsStatus: "skipped",
      });
      await store.recordJob(job);
      return job;
    }

    if (quota.sentCount >= input.dailyLimit) {
      log(logs, `Daily SMS cap ${input.dailyLimit} reached — skip`);
      const job = finish({
        status: "skip",
        reason: "سقف ۱۰ پیامک روزانه پر شده",
        slot,
        smsStatus: "skipped",
      });
      await store.recordJob(job);
      return job;
    }

    let toman: number;
    let source = "tgju";
    let messageHash: string | null = null;

    if (input.telegramText) {
      log(logs, "Parsing Telegram payload");
      const hit = extractTetherPrice(input.telegramText);
      if (!hit) {
        log(logs, "Tether price not found in message");
        const job = finish({
          status: "error",
          reason: "قیمت تتر در متن پیدا نشد",
          source: "telegram",
          smsStatus: "skipped",
        });
        await store.recordJob(job);
        return job;
      }
      toman = hit.toman;
      source = "telegram";
      messageHash = await sha256hex(
        input.telegramMessageId ?? input.telegramText,
      );
      if (quota.lastMessageHash === messageHash) {
        log(logs, "Duplicate Telegram message — skip");
        const job = finish({
          status: "skip",
          reason: "پیام تکراری تلگرام",
          source,
          priceToman: toman,
          smsStatus: "skipped",
        });
        await store.recordJob(job);
        return job;
      }
      log(logs, `Tether price detected: ${toman}`);
    } else {
      log(logs, "Fetching TGJU");
      const market = await fetchMarket({ bypassCache: true });
      if (!market.ok) {
        log(logs, "Market source unavailable");
        const job = finish({
          status: "error",
          reason: market.error,
          source: "tgju",
          smsStatus: "skipped",
        });
        await store.recordJob(job);
        return job;
      }
      toman = market.tether.toman;
      log(logs, `Tether price detected: ${toman}`);
      await store.recordTick({
        id: newId(),
        source: "tgju",
        symbol: "USDT",
        priceToman: toman,
        capturedAt: market.fetchedAt,
      });
    }

    if (!isValidTomanPrice(toman)) {
      log(logs, "Price failed sanity check");
      const job = finish({
        status: "error",
        reason: "قیمت نامعتبر",
        source,
        priceToman: toman,
        smsStatus: "skipped",
      });
      await store.recordJob(job);
      return job;
    }

    const prev = engine.lastPriceToman ?? quota.lastPriceToman;
    const delta = prev == null ? null : toman - prev;
    const smsText = formatSms({
      toman,
      delta,
      time: parts.hhmm,
    });

    let smsStatus: JobRun["smsStatus"] = "dry-run";
    if (!input.deliver) {
      log(logs, "Dry-run — SMS not sent");
      smsStatus = "dry-run";
    } else if (!input.sms) {
      log(logs, "SMS not configured");
      smsStatus = "not-configured";
    } else {
      log(logs, "Sending SMS");
      const sent = await sendSms(input.sms, smsText);
      if (!sent.ok) {
        log(logs, "SMS API error");
        const job = finish({
          status: "error",
          reason: sent.error,
          source,
          priceToman: toman,
          deltaToman: delta,
          slot,
          smsStatus: "failed",
          smsText,
        });
        await store.recordJob(job);
        return job;
      }
      smsStatus = "sent";
      log(logs, "SMS sent successfully");
      const nextSlots = slot && !slot.startsWith("manual-")
        ? [...quota.slotsSent, slot]
        : quota.slotsSent;
      await store.saveQuota({
        ...quota,
        sentCount: quota.sentCount + 1,
        slotsSent: nextSlots,
        lastPriceToman: toman,
        lastMessageHash: messageHash ?? quota.lastMessageHash,
      });
      await store.saveEngineState({
        lastPriceToman: toman,
        lastSentAt: startedAt,
      });
    }

    if (smsStatus !== "sent") {
      await store.saveEngineState({
        lastPriceToman: toman,
        lastSentAt: engine.lastSentAt,
      });
    }

    const job = finish({
      status: "ok",
      reason: smsStatus === "sent" ? "ارسال شد" : "آماده ارسال",
      source,
      priceToman: toman,
      deltaToman: delta,
      slot,
      smsStatus,
      smsText,
    });
    await store.recordJob(job);
    return job;
  } catch {
    log(logs, "Unhandled error");
    const job = finish({
      status: "error",
      reason: "خطای غیرمنتظره — اجرای بعدی مستقل ادامه می‌یابد",
      smsStatus: "skipped",
    });
    try {
      await store.recordJob(job);
    } catch {
      /* ignore store failure */
    }
    return job;
  }
}
