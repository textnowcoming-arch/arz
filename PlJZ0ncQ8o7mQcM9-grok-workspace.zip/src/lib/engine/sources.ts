import type { MarketQuote, MarketResult } from "./types.ts";

const TGJU_URLS = [
  "https://call5.tgju.org/ajax.json",
  "https://call3.tgju.org/ajax.json",
  "https://call1.tgju.org/ajax.json",
];

type TgjuItem = {
  p?: string;
  d?: string;
  dp?: number | string;
  dt?: string;
  ts?: string;
  t?: string;
};

function parseNum(raw: unknown): number | null {
  if (raw == null) return null;
  const n = Number(String(raw).replace(/,/g, "").trim());
  return Number.isFinite(n) ? n : null;
}

/** TGJU quotes rial. Convert to toman when the figure is clearly rial-scale. */
export function rialToToman(rial: number): number {
  if (rial >= 1_000_000) return Math.round(rial / 10);
  return Math.round(rial);
}

function quoteFrom(
  item: TgjuItem | undefined,
  symbol: string,
  title: string,
  asTomanFromRial: boolean,
): MarketQuote | null {
  if (!item) return null;
  const raw = parseNum(item.p);
  if (raw == null || raw <= 0) return null;
  const toman = asTomanFromRial ? rialToToman(raw) : Math.round(raw);
  const changeRaw = parseNum(item.d);
  const change =
    changeRaw == null
      ? null
      : asTomanFromRial
        ? rialToToman(changeRaw) * (item.dt === "low" ? -1 : 1)
        : Math.round(changeRaw) * (item.dt === "low" ? -1 : 1);
  const changePct = parseNum(item.dp);
  return {
    symbol,
    title,
    toman,
    change,
    changePct,
    capturedAt: new Date().toISOString(),
    sourceTime: item.ts ?? item.t ?? null,
  };
}

async function fetchJson(url: string, timeoutMs: number): Promise<unknown> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: {
        Accept: "application/json",
        "User-Agent": "NerkhResan/1.0 (price-automation)",
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchTgjuMarket(): Promise<MarketResult> {
  let lastError = "منبع نرخ در دسترس نیست";
  for (const url of TGJU_URLS) {
    try {
      const body = (await fetchJson(url, 8000)) as {
        current?: Record<string, TgjuItem>;
      };
      const current = body.current;
      if (!current) throw new Error("shape");
      const tether = quoteFrom(
        current["crypto-tether-irr"],
        "USDT",
        "تتر",
        true,
      );
      if (!tether) throw new Error("no tether");
      return {
        ok: true,
        source: "tgju",
        fetchedAt: new Date().toISOString(),
        tether,
        dollar: quoteFrom(current["price_dollar_rl"], "USD", "دلار", true),
        euro: quoteFrom(current["price_eur"], "EUR", "یورو", true),
        bitcoinUsd: parseNum(current["crypto-bitcoin"]?.p),
        ethereumUsd: parseNum(current["crypto-ethereum"]?.p),
      };
    } catch (err) {
      lastError = err instanceof Error ? err.message : "fetch failed";
    }
  }
  return { ok: false, error: `خطا در دریافت نرخ از TGJU (${lastError})` };
}

const cache: { at: number; value: MarketResult | null } = { at: 0, value: null };
const CACHE_MS = 20_000;

export async function fetchMarket(opts?: { bypassCache?: boolean }): Promise<MarketResult> {
  const now = Date.now();
  if (!opts?.bypassCache && cache.value && now - cache.at < CACHE_MS) {
    return cache.value;
  }
  const value = await fetchTgjuMarket();
  cache.at = now;
  cache.value = value;
  return value;
}
