export type TelegramUpdate = {
  update_id?: number;
  message?: {
    message_id: number;
    date: number;
    text?: string;
    caption?: string;
    from?: { id: number; is_bot?: boolean; username?: string };
    chat?: { id: number; type?: string };
  };
  channel_post?: {
    message_id: number;
    date: number;
    text?: string;
    caption?: string;
    chat?: { id: number };
  };
};

export function extractTelegramText(update: TelegramUpdate): {
  text: string;
  messageId: string;
  fromBot: boolean;
  chatId: string | null;
} | null {
  const msg = update.message ?? update.channel_post;
  if (!msg) return null;
  const text = (msg.text ?? msg.caption ?? "").trim();
  if (!text) return null;
  const fromBot = Boolean(update.message?.from?.is_bot);
  return {
    text,
    messageId: String(msg.message_id),
    fromBot,
    chatId: msg.chat?.id != null ? String(msg.chat.id) : null,
  };
}

export async function telegramSend(
  token: string,
  chatId: string,
  text: string,
): Promise<{ ok: boolean; error?: string }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(
      `https://api.telegram.org/bot${token}/sendMessage`,
      {
        method: "POST",
        signal: ctrl.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          disable_web_page_preview: true,
        }),
      },
    );
    if (!res.ok) return { ok: false, error: `Telegram HTTP ${res.status}` };
    const body = (await res.json()) as { ok?: boolean };
    if (!body.ok) return { ok: false, error: "Telegram rejected send" };
    return { ok: true };
  } catch {
    return { ok: false, error: "Telegram unavailable" };
  } finally {
    clearTimeout(timer);
  }
}
