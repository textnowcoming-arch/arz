export const TEHRAN_TZ = "Asia/Tehran";

export const DEFAULT_SLOTS = [
  "08:00",
  "10:00",
  "12:00",
  "14:00",
  "16:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
  "22:00",
] as const;

/** Cron is every 15 minutes; keep a buffer for worker cold-starts. */
export const SLOT_WINDOW_MIN = 18;

export type TehranParts = {
  dayKey: string;
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  hhmm: string;
};

export function tehranParts(now = new Date()): TehranParts {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: TEHRAN_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
  const map: Record<string, string> = {};
  for (const part of fmt.formatToParts(now)) {
    if (part.type !== "literal") map[part.type] = part.value;
  }
  const hour = Number(map.hour);
  const minute = Number(map.minute);
  return {
    dayKey: `${map.year}-${map.month}-${map.day}`,
    year: Number(map.year),
    month: Number(map.month),
    day: Number(map.day),
    hour,
    minute,
    hhmm: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
  };
}

export function tehranClock(now = new Date()): string {
  return tehranParts(now).hhmm;
}

export function tehranFaDate(now = new Date()): string {
  return new Intl.DateTimeFormat("fa-IR", {
    timeZone: TEHRAN_TZ,
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(now);
}

export function minutesOf(hhmm: string): number {
  const [h, m] = hhmm.split(":").map((x) => Number(x));
  if (!Number.isFinite(h) || !Number.isFinite(m)) return NaN;
  return h * 60 + m;
}

export function normalizeSlot(raw: string): string | null {
  const n = raw.trim();
  const m = /^(\d{1,2}):(\d{2})$/.exec(n);
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  if (h < 0 || h > 23 || min < 0 || min > 59) return null;
  return `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}`;
}

export function matchSlot(
  now: Date,
  slots: readonly string[],
  windowMin = SLOT_WINDOW_MIN,
): string | null {
  const t = tehranParts(now);
  const nowMin = t.hour * 60 + t.minute;
  let best: { slot: string; delta: number } | null = null;
  for (const slot of slots) {
    const s = minutesOf(slot);
    if (!Number.isFinite(s)) continue;
    const delta = nowMin - s;
    if (delta >= 0 && delta <= windowMin) {
      if (!best || delta < best.delta) best = { slot, delta };
    }
  }
  return best?.slot ?? null;
}

export function nextSlots(
  now: Date,
  slots: readonly string[],
  count = 3,
): { slot: string; dayOffset: number }[] {
  const t = tehranParts(now);
  const nowMin = t.hour * 60 + t.minute;
  const ordered = [...slots].filter((s) => Number.isFinite(minutesOf(s)));
  ordered.sort((a, b) => minutesOf(a) - minutesOf(b));
  const out: { slot: string; dayOffset: number }[] = [];
  for (const slot of ordered) {
    if (minutesOf(slot) >= nowMin) out.push({ slot, dayOffset: 0 });
    if (out.length >= count) return out;
  }
  for (const slot of ordered) {
    out.push({ slot, dayOffset: 1 });
    if (out.length >= count) return out;
  }
  return out;
}
