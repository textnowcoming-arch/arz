import { getSql } from "@/lib/db";
import { emptyQuota } from "./memory-store.ts";
import type { EngineState, JobRun, LogLine, QuotaState, StateStore } from "./types.ts";

type QuotaRow = {
  day_key: string;
  sent_count: number;
  slots_sent: string;
  last_price_toman: number | null;
  last_message_hash: string | null;
};

type JobRow = {
  id: string;
  started_at: string;
  status: JobRun["status"];
  reason: string | null;
  source: string | null;
  price_toman: number | null;
  delta_toman: number | null;
  slot: string | null;
  sms_status: JobRun["smsStatus"];
  logs_json: string;
};

function parseLogs(raw: string): LogLine[] {
  try {
    const parsed = JSON.parse(raw) as LogLine[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function parseSlots(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw) as string[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function jobFromRow(row: JobRow): JobRun {
  return {
    id: row.id,
    startedAt:
      typeof row.started_at === "string"
        ? row.started_at
        : new Date(row.started_at).toISOString(),
    status: row.status,
    reason: row.reason,
    source: row.source,
    priceToman: row.price_toman,
    deltaToman: row.delta_toman,
    slot: row.slot,
    smsStatus: row.sms_status,
    logs: parseLogs(row.logs_json),
    smsText: null,
  };
}

export async function createPgStore(): Promise<StateStore> {
  const sql = await getSql();

  return {
    async getQuota(dayKey) {
      const rows = await sql<QuotaRow>`
        select day_key, sent_count, slots_sent, last_price_toman, last_message_hash
        from daily_quota where day_key = ${dayKey} limit 1
      `;
      const row = rows[0];
      if (!row) return emptyQuota(dayKey);
      return {
        dayKey: row.day_key,
        sentCount: Number(row.sent_count) || 0,
        slotsSent: parseSlots(row.slots_sent),
        lastPriceToman: row.last_price_toman,
        lastMessageHash: row.last_message_hash,
      };
    },

    async saveQuota(q: QuotaState) {
      await sql`
        insert into daily_quota (day_key, sent_count, slots_sent, last_price_toman, last_message_hash)
        values (
          ${q.dayKey},
          ${q.sentCount},
          ${JSON.stringify(q.slotsSent)},
          ${q.lastPriceToman},
          ${q.lastMessageHash}
        )
        on conflict (day_key) do update set
          sent_count = excluded.sent_count,
          slots_sent = excluded.slots_sent,
          last_price_toman = excluded.last_price_toman,
          last_message_hash = excluded.last_message_hash
      `;
    },

    async getEngineState() {
      const rows = await sql<{
        last_price_toman: number | null;
        last_sent_at: string | null;
      }>`
        select last_price_toman, last_sent_at from engine_state where id = ${"default"} limit 1
      `;
      const row = rows[0];
      return {
        lastPriceToman: row?.last_price_toman ?? null,
        lastSentAt: row?.last_sent_at ?? null,
      } satisfies EngineState;
    },

    async saveEngineState(s) {
      await sql`
        insert into engine_state (id, last_price_toman, last_sent_at, updated_at)
        values (${"default"}, ${s.lastPriceToman}, ${s.lastSentAt}, now())
        on conflict (id) do update set
          last_price_toman = excluded.last_price_toman,
          last_sent_at = excluded.last_sent_at,
          updated_at = now()
      `;
    },

    async recordJob(job) {
      await sql`
        insert into job_runs (
          id, started_at, status, reason, source, price_toman, delta_toman, slot, sms_status, logs_json
        ) values (
          ${job.id},
          ${job.startedAt},
          ${job.status},
          ${job.reason},
          ${job.source},
          ${job.priceToman},
          ${job.deltaToman},
          ${job.slot},
          ${job.smsStatus},
          ${JSON.stringify(job.logs)}
        )
        on conflict (id) do nothing
      `;
      await sql`delete from job_runs where started_at < now() - interval '14 days'`;
    },

    async recordTick(tick) {
      await sql`
        insert into price_ticks (id, source, symbol, price_toman, captured_at)
        values (${tick.id}, ${tick.source}, ${tick.symbol}, ${tick.priceToman}, ${tick.capturedAt})
        on conflict (id) do nothing
      `;
      await sql`delete from price_ticks where captured_at < now() - interval '14 days'`;
    },

    async recentJobs(limit) {
      const rows = await sql<JobRow>`
        select id, started_at::text as started_at, status, reason, source,
               price_toman, delta_toman, slot, sms_status, logs_json
        from job_runs
        order by started_at desc
        limit ${limit}
      `;
      return rows.map(jobFromRow);
    },

    async recentTicks(limit) {
      const rows = await sql<{
        captured_at: string;
        price_toman: number;
        source: string;
      }>`
        select captured_at::text as captured_at, price_toman, source
        from price_ticks
        order by captured_at desc
        limit ${limit}
      `;
      return rows.map((r) => ({
        capturedAt: r.captured_at,
        priceToman: r.price_toman,
        source: r.source,
      }));
    },
  };
}
