import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { executeJob } from "@/lib/engine/job";
import { createPgStore } from "@/lib/engine/pg-store.server";
import { DEFAULT_SLOTS } from "@/lib/engine/schedule";
import { fetchMarket } from "@/lib/engine/sources";
import { smsFromEnv } from "@/lib/engine/sms";
import { extractTetherPrice } from "@/lib/engine/parser";
import { formatSms } from "@/lib/engine/format";
import { tehranClock } from "@/lib/engine/schedule";
import type { SmsConfig, SmsProvider } from "@/lib/engine/types";

const smsSchema = z
  .object({
    provider: z.enum(["kavenegar", "melipayamak", "smsir", "custom"]),
    apiUrl: z.string(),
    apiKey: z.string(),
    to: z.string(),
    from: z.string().optional(),
    username: z.string().optional(),
  })
  .nullable();

export const getMarketFn = createServerFn({ method: "GET" }).handler(async () => {
  return fetchMarket();
});

export const getHistoryFn = createServerFn({ method: "GET" }).handler(async () => {
  const store = await createPgStore();
  const [jobs, ticks, engine] = await Promise.all([
    store.recentJobs(30),
    store.recentTicks(48),
    store.getEngineState(),
  ]);
  const { tehranParts } = await import("@/lib/engine/schedule");
  const quota = await store.getQuota(tehranParts().dayKey);
  return { jobs, ticks, engine, quota };
});

export const parseTextFn = createServerFn({ method: "POST" })
  .validator(z.object({ text: z.string().max(8000) }))
  .handler(async ({ data }) => {
    const hit = extractTetherPrice(data.text);
    if (!hit) return { ok: false as const, error: "قیمت تتر پیدا نشد" };
    const smsText = formatSms({
      toman: hit.toman,
      delta: null,
      time: tehranClock(),
    });
    return { ok: true as const, toman: hit.toman, matched: hit.matched, smsText };
  });

export const runJobFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      force: z.boolean(),
      deliver: z.boolean(),
      slots: z.array(z.string()).max(24).optional(),
      dailyLimit: z.number().int().min(1).max(10).optional(),
      telegramText: z.string().max(8000).optional(),
      telegramMessageId: z.string().max(64).optional(),
      sms: smsSchema.optional(),
    }),
  )
  .handler(async ({ data }) => {
    const store = await createPgStore();
    const envSms = smsFromEnv({
      SMS_TO: process.env.SMS_TO,
      SMS_API_KEY: process.env.SMS_API_KEY,
      SMS_API_URL: process.env.SMS_API_URL,
      SMS_PROVIDER: process.env.SMS_PROVIDER,
      SMS_FROM: process.env.SMS_FROM,
      SMS_USERNAME: process.env.SMS_USERNAME,
    });
    const sms: SmsConfig | null = data.sms ?? envSms;
    return executeJob(store, {
      now: new Date(),
      force: data.force,
      deliver: data.deliver,
      slots: data.slots?.length ? data.slots : [...DEFAULT_SLOTS],
      dailyLimit: data.dailyLimit ?? 10,
      sms,
      telegramText: data.telegramText,
      telegramMessageId: data.telegramMessageId,
    });
  });

export type ClientSms = z.infer<typeof smsSchema>;
export type { SmsProvider };
