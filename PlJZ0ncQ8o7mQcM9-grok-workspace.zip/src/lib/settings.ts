import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DEFAULT_SLOTS } from "@/lib/engine/schedule";
import type { SmsProvider } from "@/lib/engine/types";

export type PriceSource = "tgju" | "telegram";

export type AppSettings = {
  priceSource: PriceSource;
  smsProvider: SmsProvider;
  smsApiUrl: string;
  smsApiKey: string;
  smsTo: string;
  smsFrom: string;
  smsUsername: string;
  slots: string[];
  dailyLimit: number;
  dryRun: boolean;
  telegramListen: boolean;
};

const defaults: AppSettings = {
  priceSource: "tgju",
  smsProvider: "kavenegar",
  smsApiUrl: "",
  smsApiKey: "",
  smsTo: "",
  smsFrom: "",
  smsUsername: "",
  slots: [...DEFAULT_SLOTS],
  dailyLimit: 10,
  dryRun: true,
  telegramListen: false,
};

type Store = AppSettings & {
  set: (patch: Partial<AppSettings>) => void;
  reset: () => void;
};

export const useSettings = create<Store>()(
  persist(
    (set) => ({
      ...defaults,
      set: (patch) => set(patch),
      reset: () => set(defaults),
    }),
    { name: "nerkhresan-settings" },
  ),
);

export function settingsToSms(s: AppSettings) {
  if (!s.smsTo || !s.smsApiKey) return null;
  return {
    provider: s.smsProvider,
    apiUrl: s.smsApiUrl,
    apiKey: s.smsApiKey,
    to: s.smsTo,
    from: s.smsFrom || undefined,
    username: s.smsUsername || undefined,
  };
}
