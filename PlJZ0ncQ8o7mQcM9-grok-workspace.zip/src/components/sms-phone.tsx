import { formatToman } from "@/lib/engine/format";

export function SmsPhone({
  text,
  emptyHint = "هنوز پیامکی ساخته نشده",
}: {
  text: string | null;
  emptyHint?: string;
}) {
  return (
    <div className="mx-auto w-full max-w-[280px]">
      <div className="rounded-[28px] border border-border-strong bg-bg p-3">
        <div className="rounded-[20px] bg-bg-subtle px-3 pb-4 pt-2">
          <div className="mx-auto mb-3 h-1.5 w-16 rounded-full bg-border-strong" />
          <p className="mb-3 text-center text-[10px] text-faint">پیامک · نرخ‌رسان</p>
          <div className="rounded-lg rounded-ss-sm bg-bg-elevated px-3 py-3">
            {text ? (
              <pre className="whitespace-pre-wrap font-sans text-[13px] leading-6 text-fg">
                {text}
              </pre>
            ) : (
              <p className="text-xs leading-6 text-muted">{emptyHint}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function PriceFigure({
  toman,
  delta,
}: {
  toman: number | null;
  delta?: number | null;
}) {
  if (toman == null) {
    return <p className="text-3xl font-medium text-muted">—</p>;
  }
  const up = (delta ?? 0) > 0;
  const down = (delta ?? 0) < 0;
  return (
    <div>
      <div className="flex flex-wrap items-end gap-x-2 gap-y-1">
        <span className="text-[clamp(2rem,8vw,3.4rem)] font-semibold leading-none tracking-tight tabular-nums">
          {formatToman(toman)}
        </span>
        <span className="mb-0.5 text-sm font-medium text-muted">تومان</span>
      </div>
      {delta != null && delta !== 0 ? (
        <p
          className={`mt-3 text-sm tabular-nums ${up ? "text-up" : down ? "text-down" : "text-muted"}`}
        >
          {up ? "+" : ""}
          {formatToman(delta)} نسبت به ارسال قبلی
        </p>
      ) : (
        <p className="mt-3 text-sm text-muted">اولین نرخ ثبت‌شده در این نشست</p>
      )}
    </div>
  );
}
