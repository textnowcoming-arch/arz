import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { Activity, ScanSearch, Settings2, Waypoints } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "داشبورد", icon: Activity },
  { to: "/parser", label: "استخراج", icon: ScanSearch },
  { to: "/settings", label: "تنظیمات", icon: Settings2 },
  { to: "/architecture", label: "معماری", icon: Waypoints },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-[1200px]">
        <aside className="sticky top-0 hidden h-dvh w-[220px] shrink-0 flex-col border-e border-border p-5 md:flex">
          <div className="mb-8">
            <p className="text-[11px] tracking-[0.18em] text-faint">NERKHRESAN</p>
            <h1 className="mt-1 text-lg font-semibold tracking-tight">نرخ‌رسان</h1>
            <p className="mt-1 text-xs leading-5 text-muted">اتوماسیون قیمت تتر</p>
          </div>
          <nav className="flex flex-1 flex-col gap-1">
            {NAV.map((item) => {
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-11 items-center gap-2.5 rounded-md px-3 text-sm transition-colors duration-150",
                    active
                      ? "bg-bg-subtle text-fg"
                      : "text-muted hover:bg-bg-subtle hover:text-fg",
                  )}
                >
                  <Icon className="size-4" strokeWidth={1.75} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <p className="text-[11px] leading-5 text-faint">
            سقف ۱۰ پیامک در روز
            <br />
            زمان تهران
          </p>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col pb-20 md:pb-0">
          <header className="flex items-center justify-between border-b border-border px-4 py-3 md:hidden">
            <div>
              <p className="text-[10px] tracking-[0.18em] text-faint">NERKHRESAN</p>
              <p className="text-sm font-medium">نرخ‌رسان</p>
            </div>
          </header>
          <main className="flex-1 px-4 py-5 sm:px-6 sm:py-7">
            <Outlet />
          </main>
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 backdrop-blur md:hidden">
        <div className="grid grid-cols-4">
          {NAV.map((item) => {
            const active =
              item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-16 flex-col items-center justify-center gap-1 text-[11px]",
                  active ? "text-fg" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={1.75} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
