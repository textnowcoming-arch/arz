import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState, type ReactNode } from "react";
import { Toaster } from "sonner";

export function AppProviders({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 20_000, refetchOnWindowFocus: false },
        },
      }),
  );
  return (
    <QueryClientProvider client={client}>
      {children}
      <Toaster
        dir="rtl"
        theme="dark"
        position="top-center"
        toastOptions={{
          style: {
            background: "#141612",
            color: "#e8ebe4",
            border: "1px solid #2a2c27",
            fontFamily: "Vazirmatn, sans-serif",
          },
        }}
      />
    </QueryClientProvider>
  );
}
