import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip as ChartTooltip,
} from "recharts";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { PriceFigure, SmsPhone } from "@/components/sms-phone";
import { formatSms, formatToman } from "@/lib/engine/format";
import {
  nextSlots,
  tehranClock,
  tehranFaDate,
  tehranParts,
} from "@/lib/engine/schedule";
import { getHistoryFn, getMarketFn, runJobFn } from "@/lib/functions";
import { settingsToSms, useSettings } from "@/lib/settings";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  loader: async () => {
    const [market, history] = await Promise.all([getMarketFn(), getHistoryFn()]);
    return { market, history };
  },
  component: Dashboard,
});

function Dashboard() {
  const initial = Route.useLoaderData();
  const settings = useSettings();
  const qc = useQueryClient();

  const marketQ = useQuery({
    queryKey: ["market"],
    queryFn: () => getMarketFn(),
    initialData: initial.market,
    refetchInterval: 60_000,
  });
  const historyQ = useQuery({
    queryKey: ["history"],
    queryFn: () => getHistoryFn(),
    initialData: initial.history,
  });

  const run = useMutation({
    mutationFn: (deliver: boolean) =>
      runJobFn({
        data: {
          force: true,
          deliver,
          slots: settings.slots,
          dailyLimit: settings.dailyLimit,
          sms: settingsToSms(settings),
        },
      }),
    onSuccess: (job) => {
      void qc.invalidateQueries({ queryKey: ["history"] });
      void qc.invalidateQueries({ queryKey: ["market"] });
      if (job.status === "ok") {
        toast(
          job.smsStatus === "sent"
            ? "پیامک ارسال شد"
            : job.smsStatus === "dry-run"
              ? "آزمایش موفق — پیامک ارسال نشد"
              : "نرخ آماده شد",
        );
      } else {
        toast(job.reason ?? "اجرا متوقف شد");
      }
    },
    onError: () => toast("اجرا ناموفق بود"),
  });

  const market = marketQ.data;
  const history = historyQ.data;
  const tether = market && market.ok ? market.tether : null;
  const lastJob = history.jobs[0] ?? null;
  const lastSms =
    lastJob?.smsText ??
    (tether
      ? formatSms({
          toman: tether.toman,
          delta: history.engine.lastPriceToman
            ? tether.toman - history.engine.lastPriceToman
            : tether.change,
          time: tehranClock(),
        })
      : null);

  const upcoming = nextSlots(new Date(), settings.slots, 4);
  const remaining = Math.max(0, settings.dailyLimit - history.quota.sentCount);
  const chartData = [...history.ticks].reverse().map((t) => ({
    t: t.capturedAt,
    p: t.priceToman,
  }));

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs text-muted">{tehranFaDate()}</p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight sm:text-3xl">
            نرخ زنده تتر
          </h1>
          <p className="mt-2 max-w-xl text-sm leading-6 text-muted">
            منبع اصلی، نرخ بازار آزاد TGJU است — همان داده‌ای که ربات‌های نرخ ارز
            معمولاً نمایش می‌دهند. تلگرام اختیاری است.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => run.mutate(false)}
            disabled={run.isPending}
          >
            اجرای آزمایشی
          </Button>
          <Button
            onClick={() => run.mutate(true)}
            disabled={run.isPending || settings.dryRun || remaining <= 0}
          >
            ارسال پیامک
          </Button>
        </div>
      </header>

      {settings.dryRun ? (
        <div className="rounded-lg border border-border bg-bg-subtle px-4 py-3 text-sm text-muted">
          حالت آزمایش روشن است. دکمه ارسال واقعی تا وقتی کلید پیامک را در تنظیمات
          بگذارید و حالت آزمایش را خاموش کنید غیرفعال می‌ماند.
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-[1.4fr_0.8fr]">
        <Card className="relative overflow-hidden p-5 sm:p-7">
          <div className="mb-6 flex flex-wrap items-center gap-2">
            <Badge>تتر / تومان</Badge>
            <Badge tone={market && market.ok ? "up" : "warn"}>
              {market && market.ok ? "TGJU متصل" : "منبع قطع"}
            </Badge>
            <span className="text-xs tabular-nums text-faint">
              {tether?.sourceTime ?? tehranClock()}
            </span>
          </div>
          {market && !market.ok ? (
            <div>
              <p className="text-lg font-medium">نرخ دریافت نشد</p>
              <p className="mt-2 text-sm text-muted">{market.error}</p>
              <Button
                className="mt-4"
                variant="outline"
                onClick={() => marketQ.refetch()}
              >
                تلاش دوباره
              </Button>
            </div>
          ) : (
            <PriceFigure
              toman={tether?.toman ?? null}
              delta={
                history.engine.lastPriceToman != null && tether
                  ? tether.toman - history.engine.lastPriceToman
                  : (tether?.change ?? null)
              }
            />
          )}
          {chartData.length > 1 ? (
            <div className="mt-8 h-28" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="pfill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--color-up)" stopOpacity={0.28} />
                      <stop offset="100%" stopColor="var(--color-up)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <ChartTooltip
                    contentStyle={{
                      background: "#141612",
                      border: "1px solid #2a2c27",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                    formatter={(v) => [
                      `${Number(v).toLocaleString("en-US")} تومان`,
                      "تتر",
                    ]}
                  />
                  <Area
                    type="monotone"
                    dataKey="p"
                    stroke="var(--color-up)"
                    fill="url(#pfill)"
                    strokeWidth={1.6}
                    dot={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <p className="mt-8 text-xs text-faint">
              بعد از چند اجرا، روند قیمت همین‌جا رسم می‌شود.
            </p>
          )}
        </Card>

        <Card className="flex flex-col">
          <CardTitle>پیش‌نمایش پیامک</CardTitle>
          <CardHint className="mt-1 mb-4">
            همان متنی که به موبایل می‌رسد — فقط تتر، اختلاف، ساعت تهران.
          </CardHint>
          <SmsPhone text={lastSms} />
        </Card>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="پیامک امروز"
          value={`${history.quota.sentCount} / ${settings.dailyLimit}`}
          hint={`${remaining} باقی‌مانده`}
        />
        <Stat
          label="نوبت بعدی"
          value={upcoming[0] ? upcoming[0].slot : "—"}
          hint={
            upcoming[0]?.dayOffset === 1 ? "فردا · تهران" : "امروز · تهران"
          }
        />
        <Stat
          label="دلار آزاد"
          value={
            market && market.ok && market.dollar
              ? formatToman(market.dollar.toman)
              : "—"
          }
          hint="نمایش؛ پیامک نمی‌شود"
        />
        <Stat
          label="آخرین وضعیت"
          value={statusFa(lastJob?.status)}
          hint={lastJob?.reason ?? "هنوز اجرایی نبوده"}
        />
      </div>

      <Card>
        <div className="mb-4 flex items-center justify-between gap-3">
          <CardTitle>زمان‌بندی امروز</CardTitle>
          <p className="text-xs text-faint">پنجره هر نوبت ۱۸ دقیقه</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {settings.slots.map((slot) => {
            const done = history.quota.slotsSent.includes(slot);
            return (
              <span
                key={slot}
                className={cn(
                  "rounded-md border px-3 py-2 text-sm tabular-nums",
                  done
                    ? "border-up/30 bg-up/10 text-up"
                    : "border-border text-muted",
                )}
              >
                {slot}
              </span>
            );
          })}
        </div>
      </Card>

      <Card>
        <CardTitle>گزارش اجرا</CardTitle>
        <CardHint className="mt-1 mb-4">
          خطاها ثبت می‌شوند و اجرای بعدی مستقل ادامه پیدا می‌کند. کلید و شماره در لاگ نیست.
        </CardHint>
        {history.jobs.length === 0 ? (
          <p className="text-sm text-muted">
            هنوز اجرایی ثبت نشده. «اجرای آزمایشی» را بزنید تا مسیر کامل تست شود.
          </p>
        ) : (
          <ul className="divide-y divide-border">
            {history.jobs.slice(0, 12).map((job) => (
              <li
                key={job.id}
                className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="text-sm">
                    {statusFa(job.status)}
                    {job.priceToman != null ? (
                      <span className="ms-2 tabular-nums text-muted">
                        {formatToman(job.priceToman)} تومان
                      </span>
                    ) : null}
                  </p>
                  <p className="text-xs text-faint">{job.reason}</p>
                </div>
                <p className="text-xs tabular-nums text-faint">
                  {tehranParts(new Date(job.startedAt)).hhmm}
                  {job.slot ? ` · ${job.slot}` : ""}
                  {job.smsStatus ? ` · ${smsFa(job.smsStatus)}` : ""}
                </p>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <Card>
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-2 text-xl font-medium tabular-nums tracking-tight">{value}</p>
      <p className="mt-1 text-xs text-faint">{hint}</p>
    </Card>
  );
}

function statusFa(s?: string | null) {
  if (s === "ok") return "موفق";
  if (s === "skip") return "رد شد";
  if (s === "error") return "خطا";
  return "نامشخص";
}

function smsFa(s: string) {
  if (s === "sent") return "ارسال شد";
  if (s === "dry-run") return "آزمایشی";
  if (s === "failed") return "خطای پیامک";
  if (s === "not-configured") return "بدون پیکربندی";
  return "ارسال نشد";
}
