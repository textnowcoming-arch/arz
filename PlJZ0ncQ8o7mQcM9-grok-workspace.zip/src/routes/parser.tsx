import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/input";
import { SmsPhone } from "@/components/sms-phone";
import { formatSms, formatToman } from "@/lib/engine/format";
import { extractTetherPrice } from "@/lib/engine/parser";
import { tehranClock } from "@/lib/engine/schedule";
import { runJobFn } from "@/lib/functions";
import { settingsToSms, useSettings } from "@/lib/settings";

export const Route = createFileRoute("/parser")({ component: ParserPage });

const SAMPLE = `◄ نرخ ارز و طلا در بازار آزاد :

• تاریخ : دوشنبه ۲۳ شهریور ۱۴۰۵
• ساعت : ۱۹:۴۱

🇺🇸 دلار : 232,085 تومان
🇪🇺 یورو : 268,970 تومان

◄ قیمت ارزهای دیجیتال:

💵 تتر : 229,852 تومان
💰 بیتکوین : 78,471.19 دلار
💰 اتریوم : 2,505.8 دلار`;

function ParserPage() {
  const [text, setText] = useState(SAMPLE);
  const [running, setRunning] = useState(false);
  const settings = useSettings();
  const hit = useMemo(() => extractTetherPrice(text), [text]);
  const sms = hit
    ? formatSms({ toman: hit.toman, delta: 1250, time: tehranClock() })
    : null;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">آزمایش استخراج</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
          پیام ربات نرخ ارز را اینجا بچسبانید. استخراج به شماره خط وابسته نیست و
          فاصله یا دونقطه را تحمل می‌کند. اگر قیمت پیدا نشود، پیامک ارسال نمی‌شود.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <CardTitle>متن ورودی</CardTitle>
          <CardHint className="mt-1 mb-3">نمونه ربات از قبل آمده؛ می‌توانید عوضش کنید.</CardHint>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            spellCheck={false}
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={() => setText(SAMPLE)}>
              بازگردانی نمونه
            </Button>
            <Button
              size="sm"
              disabled={!hit || running}
              onClick={async () => {
                setRunning(true);
                try {
                  const job = await runJobFn({
                    data: {
                      force: true,
                      deliver: false,
                      telegramText: text,
                      telegramMessageId: `parser-${Date.now()}`,
                      slots: settings.slots,
                      dailyLimit: settings.dailyLimit,
                      sms: settingsToSms(settings),
                    },
                  });
                  toast(job.reason ?? job.status);
                } catch {
                  toast("اجرا ناموفق بود");
                } finally {
                  setRunning(false);
                }
              }}
            >
              اجرای مسیر کامل
            </Button>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardTitle>نتیجه</CardTitle>
            {hit ? (
              <div className="mt-3 space-y-2">
                <Badge tone="up">پیدا شد</Badge>
                <p className="text-2xl font-semibold tabular-nums">
                  {formatToman(hit.toman)}{" "}
                  <span className="text-sm font-medium text-muted">تومان</span>
                </p>
                <p className="text-xs text-faint">تطبیق: {hit.matched}</p>
              </div>
            ) : (
              <div className="mt-3 space-y-2">
                <Badge tone="down">قیمت تتر پیدا نشد</Badge>
                <p className="text-sm text-muted">
                  پیامک در این حالت ارسال نمی‌شود و خطا فقط در گزارش می‌ماند.
                </p>
              </div>
            )}
          </Card>
          <Card>
            <CardTitle>پیامک تولیدی</CardTitle>
            <div className="mt-4">
              <SmsPhone text={sms} emptyHint="بدون قیمت، متنی ساخته نمی‌شود" />
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
