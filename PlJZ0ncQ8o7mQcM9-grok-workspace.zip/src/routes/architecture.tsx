import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardHint, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/architecture")({
  component: ArchitecturePage,
});

export function ArchitecturePage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">معماری نهایی</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
          معماری اولیه (بات تلگرام در گروه، ارسال «نرخ ارز»، خواندن پاسخ ربات دیگر)
          پیاده نشد؛ محدودیت واقعی تلگرام آن را ناپایدار می‌کند. هدف شما حفظ شده:
          نرخ تتر همان بازار آزاد، استخراج، پیامک خودکار، بدون اکانت شخصی، حداکثر
          ۱۰ پیامک در روز.
        </p>
      </header>

      <Card>
        <CardTitle>چرا مسیر بات‌به‌بات گروه کار نمی‌کند</CardTitle>
        <div className="mt-3 space-y-3 text-sm leading-7 text-muted">
          <p>
            طبق FAQ رسمی تلگرام، بات‌ها پیام بات دیگر را نمی‌بینند تا حلقه پیش نیاید.
            از مه ۲۰۲۶ حالت Bot-to-Bot اضافه شده، اما:
          </p>
          <ul className="list-disc space-y-1 ps-5">
            <li>
              ربات نرخ ارز باید پیام بات شما («نرخ ارز») را ببیند. این تنظیم روی ربات
              آن‌هاست و در کنترل شما نیست.
            </li>
            <li>
              حتی اگر بات شما ادمین باشد و Privacy را خاموش کند، تریگر همچنان به
              همکاری ربات مقابل وابسته است.
            </li>
            <li>
              انتظار برای پاسخ روی ورکر بدون حالت، شکننده است: تأخیر، پیام نامرتبط،
              قطعی API.
            </li>
          </ul>
          <p>
            اکانت شخصی طبق الزام شما کنار گذاشته شد. Userbot جدا هم نیاز به شماره
            و اتصال پایدار دارد و روی Cloudflare Worker مناسب نیست.
          </p>
        </div>
      </Card>

      <Card>
        <CardTitle>معماری انتخاب‌شده</CardTitle>
        <pre className="mt-3 overflow-x-auto rounded-md bg-bg p-4 text-xs leading-6 text-muted" dir="ltr">
{`Cron هر ۱۵ دقیقه
    ↓
بررسی ساعت تهران با نوبت‌های قابل تنظیم
    ↓
TGJU (بازار آزاد)  →  استخراج تتر
    ↓
سقف روزانه + جلوگیری از تکرار نوبت
    ↓
قالب پیامک   →   پنل SMS
    ↓
ثبت گزارش بدون کلید و شماره`}
        </pre>
        <p className="mt-3 text-sm leading-7 text-muted">
          TGJU همان منبعی است که اکثر ربات‌های «نرخ ارز» از آن می‌خوانند. دلار آزاد و
          تتر نمونه‌تان با همین منبع هم‌خوان است. دقت بالا، بدون گروه، بدون اکانت
          شخصی، روی ورکر یا همین اپ پایدار است.
        </p>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardTitle>مسیر تلگرام — اختیاری</CardTitle>
          <CardHint className="mt-2 leading-7">
            اگر ربات نرخ در کانال یا گروه به‌صورت خودکار پست می‌کند، بات خودتان را
            ادمین کنید، Privacy را خاموش کنید، Bot-to-Bot را روشن کنید و وب‌هوک
            `/api/telegram` را بگذارید. سیستم پیام را پارس می‌کند؛ اگر تتر نباشد
            پیامک نمی‌رود. ارسال «نرخ ارز» از طرف بات شما عمداً پیش‌فرض نیست.
          </CardHint>
        </Card>
        <Card>
          <CardTitle>اولویت‌ها</CardTitle>
          <ol className="mt-2 list-decimal space-y-1 ps-5 text-sm leading-7 text-muted">
            <li>دقت نرخ بازار آزاد</li>
            <li>پایداری و اجرای مستقل بعد از خطا</li>
            <li>بدون اکانت شخصی تلگرام</li>
            <li>کاملاً خودکار با کرون</li>
            <li>کلیدها در Secret، نه در سورس</li>
            <li>سقف ۱۰ پیامک حتی با اجرای مجدد</li>
          </ol>
        </Card>
      </div>

      <Card>
        <CardTitle>راهنمای راه‌اندازی</CardTitle>
        <div className="mt-3 space-y-4 text-sm leading-7 text-muted">
          <section>
            <h3 className="font-medium text-fg">۱. تست همین‌جا</h3>
            <p>
              داشبورد نرخ زنده را نشان می‌دهد. «اجرای آزمایشی» مسیر را بدون پیامک
              طی می‌کند. در صفحه استخراج، متن ربات را پارس کنید.
            </p>
          </section>
          <section>
            <h3 className="font-medium text-fg">۲. اتصال پیامک</h3>
            <p>
              در{" "}
              <Link to="/settings" className="text-fg underline-offset-4 hover:underline">
                تنظیمات
              </Link>{" "}
              پنل را انتخاب کنید، شماره و کلید را بگذارید، حالت آزمایش را خاموش
              کنید. اگر مستندات واقعی پنل را بفرستید، آداپتر دقیق همان پنل اضافه
              می‌شود.
            </p>
          </section>
          <section>
            <h3 className="font-medium text-fg">۳. زمان‌بندی و شماره</h3>
            <p>
              نوبت‌ها و سقف روزانه از تنظیمات عوض می‌شوند. شماره فقط در فیلد
              «گیرنده» یا متغیر SMS_TO است.
            </p>
          </section>
          <section>
            <h3 className="font-medium text-fg">۴. استقرار خودکار</h3>
            <p>
              همین اپ با مسیر `/api/cron` هر ۱۵ دقیقه نوبت تهران را چک می‌کند.
              هدر `X-Cron-Secret` را با CRON_SECRET بگذارید. جایگزین Cloudflare:
              پوشه worker با wrangler، KV برای وضعیت، همان موتور نرخ و پیامک.
            </p>
          </section>
        </div>
      </Card>
    </div>
  );
}
