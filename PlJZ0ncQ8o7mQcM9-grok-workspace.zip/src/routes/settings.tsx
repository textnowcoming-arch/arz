import { createFileRoute } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Input, Label } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { DEFAULT_SLOTS, normalizeSlot } from "@/lib/engine/schedule";
import { useSettings, type PriceSource } from "@/lib/settings";
import type { SmsProvider } from "@/lib/engine/types";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

const PROVIDERS: { id: SmsProvider; label: string; hint: string }[] = [
  { id: "kavenegar", label: "کاوه‌نگار", hint: "API Key در مسیر URL" },
  { id: "melipayamak", label: "ملی‌پیامک", hint: "نام کاربری + رمز" },
  { id: "smsir", label: "SMS.ir", hint: "هدر X-API-KEY" },
  { id: "custom", label: "دلخواه", hint: "POST JSON با to و message" },
];

function SettingsPage() {
  const s = useSettings();

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">تنظیمات</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
          کلیدها روی همین دستگاه ذخیره می‌شوند، نه در کد. در استقرار نهایی از
          Secretهای سرور استفاده کنید تا در مرورگر نمانند.
        </p>
      </header>

      <Card>
        <div className="flex items-start justify-between gap-4">
          <div>
            <CardTitle>حالت آزمایش</CardTitle>
            <CardHint className="mt-1">
              روشن بماند تا وقتی API پیامک را تست نکرده‌اید. سقف روزانه در هر دو حالت
              رعایت می‌شود.
            </CardHint>
          </div>
          <div dir="ltr">
            <Switch
              checked={s.dryRun}
              onCheckedChange={(v) => s.set({ dryRun: v })}
              aria-label="حالت آزمایش"
            />
          </div>
        </div>
      </Card>

      <Card>
        <CardTitle>منبع نرخ</CardTitle>
        <CardHint className="mt-1 mb-4">
          پیشنهاد ما TGJU است. تلگرام فقط اگر ربات نرخ در کانال/گروه به‌صورت خودکار
          پست کند و بات شما ادمین باشد.
        </CardHint>
        <div className="grid gap-2 sm:grid-cols-2">
          {(
            [
              ["tgju", "TGJU — بازار آزاد"],
              ["telegram", "تلگرام — شنونده اختیاری"],
            ] as [PriceSource, string][]
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => s.set({ priceSource: id })}
              className={`h-11 rounded-md border px-3 text-start text-sm ${
                s.priceSource === id
                  ? "border-accent bg-bg-subtle text-fg"
                  : "border-border text-muted"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <CardTitle>پیامک</CardTitle>
        <CardHint className="mt-1 mb-4">
          شماره، آدرس API و کلید را پر کنید. کلید در لاگ چاپ نمی‌شود.
        </CardHint>
        <div className="mb-4 flex flex-wrap gap-2">
          {PROVIDERS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => s.set({ smsProvider: p.id })}
              className={`rounded-full border px-3 py-1.5 text-xs ${
                s.smsProvider === p.id
                  ? "border-accent bg-bg-subtle text-fg"
                  : "border-border text-muted"
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="شماره گیرنده">
            <Input
              value={s.smsTo}
              onChange={(e) => s.set({ smsTo: e.target.value })}
              placeholder="0912…"
              inputMode="tel"
              autoComplete="off"
            />
          </Field>
          <Field label="کلید API">
            <Input
              type="password"
              value={s.smsApiKey}
              onChange={(e) => s.set({ smsApiKey: e.target.value })}
              placeholder="در کد سخت نمی‌شود"
              autoComplete="off"
            />
          </Field>
          <Field label="آدرس API (اختیاری)">
            <Input
              value={s.smsApiUrl}
              onChange={(e) => s.set({ smsApiUrl: e.target.value })}
              placeholder="خالی = پیش‌فرض پنل"
              dir="ltr"
            />
          </Field>
          <Field label="خط ارسال / از">
            <Input
              value={s.smsFrom}
              onChange={(e) => s.set({ smsFrom: e.target.value })}
              dir="ltr"
            />
          </Field>
          {s.smsProvider === "melipayamak" ? (
            <Field label="نام کاربری ملی‌پیامک">
              <Input
                value={s.smsUsername}
                onChange={(e) => s.set({ smsUsername: e.target.value })}
              />
            </Field>
          ) : null}
        </div>
      </Card>

      <Card>
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <CardTitle>زمان‌بندی</CardTitle>
            <CardHint className="mt-1">حداکثر ۱۰ نوبت در روز · ساعت تهران</CardHint>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => s.set({ slots: [...DEFAULT_SLOTS] })}
          >
            پیش‌فرض
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {s.slots.map((slot, i) => (
            <input
              key={`${slot}-${i}`}
              type="time"
              value={slot}
              onChange={(e) => {
                const next = normalizeSlot(e.target.value);
                if (!next) return;
                const slots = [...s.slots];
                slots[i] = next;
                s.set({ slots });
              }}
              className="h-11 rounded-md border border-border bg-bg px-3 text-sm tabular-nums text-fg"
            />
          ))}
        </div>
        <div className="mt-4 flex gap-2">
          <Button
            variant="outline"
            size="sm"
            disabled={s.slots.length >= 10}
            onClick={() => s.set({ slots: [...s.slots, "12:00"] })}
          >
            افزودن نوبت
          </Button>
          <Button
            variant="ghost"
            size="sm"
            disabled={s.slots.length <= 1}
            onClick={() => s.set({ slots: s.slots.slice(0, -1) })}
          >
            حذف آخرین
          </Button>
        </div>
        <Field label="سقف روزانه" className="mt-4 max-w-40">
          <Input
            type="number"
            min={1}
            max={10}
            value={s.dailyLimit}
            onChange={(e) =>
              s.set({
                dailyLimit: Math.min(10, Math.max(1, Number(e.target.value) || 1)),
              })
            }
          />
        </Field>
      </Card>

      <Card>
        <CardTitle>متغیرهای سرور (استقرار)</CardTitle>
        <CardHint className="mt-1 mb-3">
          این نام‌ها را در Secrets بگذارید — هرگز داخل سورس.
        </CardHint>
        <ul className="space-y-1 font-mono text-xs leading-6 text-muted" dir="ltr">
          <li>SMS_API_URL</li>
          <li>SMS_API_KEY</li>
          <li>SMS_TO</li>
          <li>SMS_PROVIDER</li>
          <li>CRON_SECRET</li>
          <li>TELEGRAM_BOT_TOKEN</li>
          <li>TELEGRAM_WEBHOOK_SECRET</li>
        </ul>
      </Card>
    </div>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}
