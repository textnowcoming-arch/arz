import { createFileRoute } from "@tanstack/react-router";
import { executeJob } from "@/lib/engine/job";
import { createPgStore } from "@/lib/engine/pg-store.server";
import { DEFAULT_SLOTS } from "@/lib/engine/schedule";
import { smsFromEnv } from "@/lib/engine/sms";
import {
  extractTelegramText,
  type TelegramUpdate,
} from "@/lib/engine/telegram";

export const Route = createFileRoute("/api/telegram")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.TELEGRAM_WEBHOOK_SECRET?.trim();
        const header = request.headers.get("x-telegram-bot-api-secret-token");
        const query = new URL(request.url).searchParams.get("secret");
        if (secret && header !== secret && query !== secret) {
          return Response.json({ ok: false }, { status: 401 });
        }

        let update: TelegramUpdate;
        try {
          update = (await request.json()) as TelegramUpdate;
        } catch {
          return Response.json({ ok: false }, { status: 400 });
        }

        const extracted = extractTelegramText(update);
        if (!extracted) return Response.json({ ok: true, ignored: true });

        const store = await createPgStore();
        const sms = smsFromEnv({
          SMS_TO: process.env.SMS_TO,
          SMS_API_KEY: process.env.SMS_API_KEY,
          SMS_API_URL: process.env.SMS_API_URL,
          SMS_PROVIDER: process.env.SMS_PROVIDER,
          SMS_FROM: process.env.SMS_FROM,
          SMS_USERNAME: process.env.SMS_USERNAME,
        });

        const job = await executeJob(store, {
          now: new Date(),
          force: true,
          deliver: Boolean(sms) && process.env.SMS_DRY_RUN !== "1",
          slots: [...DEFAULT_SLOTS],
          dailyLimit: Math.min(
            10,
            Math.max(1, Number(process.env.DAILY_LIMIT) || 10),
          ),
          sms,
          telegramText: extracted.text,
          telegramMessageId: extracted.messageId,
        });

        return Response.json({
          ok: true,
          status: job.status,
          reason: job.reason,
        });
      },
    },
  },
});
