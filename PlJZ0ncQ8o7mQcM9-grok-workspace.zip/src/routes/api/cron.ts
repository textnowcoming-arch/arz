import { createFileRoute } from "@tanstack/react-router";
import { executeJob } from "@/lib/engine/job";
import { createPgStore } from "@/lib/engine/pg-store.server";
import { DEFAULT_SLOTS } from "@/lib/engine/schedule";
import { smsFromEnv } from "@/lib/engine/sms";

async function handle({ request }: { request: Request }) {
  const secret = process.env.CRON_SECRET?.trim();
  const given =
    request.headers.get("x-cron-secret") ??
    new URL(request.url).searchParams.get("secret") ??
    "";
  if (secret && given !== secret) {
    return Response.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }

  const store = await createPgStore();
  const sms = smsFromEnv({
    SMS_TO: process.env.SMS_TO,
    SMS_API_KEY: process.env.SMS_API_KEY,
    SMS_API_URL: process.env.SMS_API_URL,
    SMS_PROVIDER: process.env.SMS_PROVIDER,
    SMS_FROM: process.env.SMS_FROM,
    SMS_USERNAME: process.env.SMS_USERNAME,
  });
  const slots = (process.env.SCHEDULE_SLOTS ?? DEFAULT_SLOTS.join(","))
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const source = process.env.PRICE_SOURCE?.trim() || "tgju";
  if (source === "telegram") {
    return Response.json({
      ok: true,
      skipped: true,
      reason: "telegram-listen-mode",
    });
  }

  const job = await executeJob(store, {
    now: new Date(),
    force: false,
    deliver: Boolean(sms) && process.env.SMS_DRY_RUN !== "1",
    slots,
    dailyLimit: Math.min(10, Math.max(1, Number(process.env.DAILY_LIMIT) || 10)),
    sms,
  });

  return Response.json({
    ok: job.status !== "error",
    status: job.status,
    reason: job.reason,
    priceToman: job.priceToman,
    slot: job.slot,
    smsStatus: job.smsStatus,
  });
}

export const Route = createFileRoute("/api/cron")({
  server: {
    handlers: {
      GET: handle,
      POST: handle,
    },
  },
});
