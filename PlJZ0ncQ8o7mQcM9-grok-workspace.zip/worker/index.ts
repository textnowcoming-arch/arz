/**
 * Cloudflare Worker entry — same engine as the web app.
 * Bind KV namespace `STATE` and set SMS_* / CRON secrets in the dashboard.
 */
import { executeJob } from "../src/lib/engine/job.ts";
import { emptyQuota } from "../src/lib/engine/memory-store.ts";
import { DEFAULT_SLOTS } from "../src/lib/engine/schedule.ts";
import { smsFromEnv } from "../src/lib/engine/sms.ts";
import {
  extractTelegramText,
  type TelegramUpdate,
} from "../src/lib/engine/telegram.ts";
import type { EngineState, JobRun, QuotaState, StateStore } from "../src/lib/engine/types.ts";

export interface Env {
  STATE: KVNamespace;
  SMS_API_URL?: string;
  SMS_API_KEY?: string;
  SMS_TO?: string;
  SMS_PROVIDER?: string;
  SMS_FROM?: string;
  SMS_USERNAME?: string;
  SMS_DRY_RUN?: string;
  CRON_SECRET?: string;
  DAILY_LIMIT?: string;
  SCHEDULE_SLOTS?: string;
  PRICE_SOURCE?: string;
  TELEGRAM_WEBHOOK_SECRET?: string;
}

function kvStore(kv: KVNamespace): StateStore {
  return {
    async getQuota(dayKey) {
      const raw = await kv.get(`quota:${dayKey}`, "json");
      return (raw as QuotaState | null) ?? emptyQuota(dayKey);
    },
    async saveQuota(q) {
      await kv.put(`quota:${q.dayKey}`, JSON.stringify(q), {
        expirationTtl: 60 * 60 * 48,
      });
    },
    async getEngineState() {
      const raw = await kv.get("engine", "json");
      return (raw as EngineState | null) ?? { lastPriceToman: null, lastSentAt: null };
    },
    async saveEngineState(s) {
      await kv.put("engine", JSON.stringify(s));
    },
    async recordJob(job: JobRun) {
      const key = "jobs";
      const prev = ((await kv.get(key, "json")) as JobRun[] | null) ?? [];
      const next = [job, ...prev].slice(0, 100);
      await kv.put(key, JSON.stringify(next));
    },
    async recordTick(tick) {
      const key = "ticks";
      const prev =
        ((await kv.get(key, "json")) as {
          capturedAt: string;
          priceToman: number;
          source: string;
        }[] | null) ?? [];
      const next = [
        {
          capturedAt: tick.capturedAt,
          priceToman: tick.priceToman,
          source: tick.source,
        },
        ...prev,
      ].slice(0, 200);
      await kv.put(key, JSON.stringify(next));
    },
    async recentJobs(limit) {
      const prev = ((await kv.get("jobs", "json")) as JobRun[] | null) ?? [];
      return prev.slice(0, limit);
    },
    async recentTicks(limit) {
      const prev =
        ((await kv.get("ticks", "json")) as {
          capturedAt: string;
          priceToman: number;
          source: string;
        }[] | null) ?? [];
      return prev.slice(0, limit);
    },
  };
}

async function runScheduled(env: Env, force: boolean) {
  if ((env.PRICE_SOURCE ?? "tgju") === "telegram" && !force) {
    return { skipped: true, reason: "telegram-listen-mode" };
  }
  const sms = smsFromEnv(env);
  const slots = (env.SCHEDULE_SLOTS ?? DEFAULT_SLOTS.join(","))
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  return executeJob(kvStore(env.STATE), {
    now: new Date(),
    force,
    deliver: Boolean(sms) && env.SMS_DRY_RUN !== "1",
    slots,
    dailyLimit: Math.min(10, Math.max(1, Number(env.DAILY_LIMIT) || 10)),
    sms,
  });
}

export default {
  async scheduled(_event: ScheduledEvent, env: Env, _ctx: ExecutionContext) {
    await runScheduled(env, false);
  },

  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/cron") {
      const given =
        request.headers.get("x-cron-secret") ?? url.searchParams.get("secret") ?? "";
      if (env.CRON_SECRET && given !== env.CRON_SECRET) {
        return Response.json({ ok: false }, { status: 401 });
      }
      const job = await runScheduled(env, url.searchParams.get("force") === "1");
      return Response.json(job);
    }

    if (url.pathname === "/telegram" && request.method === "POST") {
      const secret = env.TELEGRAM_WEBHOOK_SECRET;
      const header = request.headers.get("x-telegram-bot-api-secret-token");
      const query = url.searchParams.get("secret");
      if (secret && header !== secret && query !== secret) {
        return Response.json({ ok: false }, { status: 401 });
      }
      const update = (await request.json()) as TelegramUpdate;
      const extracted = extractTelegramText(update);
      if (!extracted) return Response.json({ ok: true, ignored: true });
      const sms = smsFromEnv(env);
      const job = await executeJob(kvStore(env.STATE), {
        now: new Date(),
        force: true,
        deliver: Boolean(sms) && env.SMS_DRY_RUN !== "1",
        slots: [...DEFAULT_SLOTS],
        dailyLimit: Math.min(10, Math.max(1, Number(env.DAILY_LIMIT) || 10)),
        sms,
        telegramText: extracted.text,
        telegramMessageId: extracted.messageId,
      });
      return Response.json({ ok: true, status: job.status, reason: job.reason });
    }

    if (url.pathname === "/health") {
      return Response.json({ ok: true, service: "nerkhresan" });
    }

    return new Response("nerkhresan worker", { status: 200 });
  },
};
