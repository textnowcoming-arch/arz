# نرخ‌رسان — Cloudflare Worker

جایگزین اختیاری برای کرون همین اپ. موتور نرخ، پارس، سقف روزانه و پیامک یکی است.

## Secrets

SMS_API_URL
SMS_API_KEY
SMS_TO
SMS_PROVIDER
CRON_SECRET
TELEGRAM_WEBHOOK_SECRET
SMS_DRY_RUN=1 تا وقتی تست تمام نشده

## Cron

هر ۱۵ دقیقه، ساعت تهران با نوبت‌های تنظیم‌شده مطابقت داده می‌شود. نوبت تکراری در همان روز پیامک نمی‌فرستد. سقف ۱۰ تا حتی با اجرای مجدد رعایت می‌شود.
