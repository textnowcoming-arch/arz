//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CDYuZAKv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/architecture",
			"/parser",
			"/settings",
			"/api/cron",
			"/api/telegram"
		],
		preloads: ["/assets/index-BExJbA2q.js", "/assets/card-DJqfm0of.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BExJbA2q.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-AasooMMK.js",
			"/assets/sms-phone-D4HLcdYf.js",
			"/assets/settings-C05XxHsj.js"
		]
	},
	"/parser": {
		filePath: "/workspace/src/routes/parser.tsx",
		children: void 0,
		preloads: [
			"/assets/parser-Ctdes45C.js",
			"/assets/sms-phone-D4HLcdYf.js",
			"/assets/settings-C05XxHsj.js",
			"/assets/input-CI85K2Ok.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BOTFtVFB.js",
			"/assets/settings-C05XxHsj.js",
			"/assets/input-CI85K2Ok.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
