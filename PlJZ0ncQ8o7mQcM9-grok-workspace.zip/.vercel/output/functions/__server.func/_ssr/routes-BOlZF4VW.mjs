import { c as formatToman, h as tehranParts, l as nextSlots, m as tehranFaDate, p as tehranClock, s as formatSms } from "./pg-store.server-Dm1BeILm.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Route$5, c as getMarketFn, i as CardTitle, l as runJobFn, n as Card, o as cn, r as CardHint, s as getHistoryFn } from "./router-B4EFIl9N.mjs";
import { n as PriceFigure, r as SmsPhone, t as Badge } from "./sms-phone-Dl_77uNp.mjs";
import { n as settingsToSms, r as useSettings, t as Button } from "./settings-D6uC_Qvm.mjs";
import { i as Tooltip, n as Area, r as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BOlZF4VW.js
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const initial = Route$5.useLoaderData();
	const settings = useSettings();
	const qc = useQueryClient();
	const marketQ = useQuery({
		queryKey: ["market"],
		queryFn: () => getMarketFn(),
		initialData: initial.market,
		refetchInterval: 6e4
	});
	const historyQ = useQuery({
		queryKey: ["history"],
		queryFn: () => getHistoryFn(),
		initialData: initial.history
	});
	const run = useMutation({
		mutationFn: (deliver) => runJobFn({ data: {
			force: true,
			deliver,
			slots: settings.slots,
			dailyLimit: settings.dailyLimit,
			sms: settingsToSms(settings)
		} }),
		onSuccess: (job) => {
			qc.invalidateQueries({ queryKey: ["history"] });
			qc.invalidateQueries({ queryKey: ["market"] });
			if (job.status === "ok") toast(job.smsStatus === "sent" ? "پیامک ارسال شد" : job.smsStatus === "dry-run" ? "آزمایش موفق — پیامک ارسال نشد" : "نرخ آماده شد");
			else toast(job.reason ?? "اجرا متوقف شد");
		},
		onError: () => toast("اجرا ناموفق بود")
	});
	const market = marketQ.data;
	const history = historyQ.data;
	const tether = market && market.ok ? market.tether : null;
	const lastJob = history.jobs[0] ?? null;
	const lastSms = lastJob?.smsText ?? (tether ? formatSms({
		toman: tether.toman,
		delta: history.engine.lastPriceToman ? tether.toman - history.engine.lastPriceToman : tether.change,
		time: tehranClock()
	}) : null);
	const upcoming = nextSlots(/* @__PURE__ */ new Date(), settings.slots, 4);
	const remaining = Math.max(0, settings.dailyLimit - history.quota.sentCount);
	const chartData = [...history.ticks].reverse().map((t) => ({
		t: t.capturedAt,
		p: t.priceToman
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: tehranFaDate()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-semibold tracking-tight sm:text-3xl",
						children: "نرخ زنده تتر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm leading-6 text-muted",
						children: "منبع اصلی، نرخ بازار آزاد TGJU است — همان داده‌ای که ربات‌های نرخ ارز معمولاً نمایش می‌دهند. تلگرام اختیاری است."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => run.mutate(false),
						disabled: run.isPending,
						children: "اجرای آزمایشی"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => run.mutate(true),
						disabled: run.isPending || settings.dryRun || remaining <= 0,
						children: "ارسال پیامک"
					})]
				})]
			}),
			settings.dryRun ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg border border-border bg-bg-subtle px-4 py-3 text-sm text-muted",
				children: "حالت آزمایش روشن است. دکمه ارسال واقعی تا وقتی کلید پیامک را در تنظیمات بگذارید و حالت آزمایش را خاموش کنید غیرفعال می‌ماند."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[1.4fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "relative overflow-hidden p-5 sm:p-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "تتر / تومان" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: market && market.ok ? "up" : "warn",
									children: market && market.ok ? "TGJU متصل" : "منبع قطع"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs tabular-nums text-faint",
									children: tether?.sourceTime ?? tehranClock()
								})
							]
						}),
						market && !market.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-medium",
								children: "نرخ دریافت نشد"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: market.error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-4",
								variant: "outline",
								onClick: () => marketQ.refetch(),
								children: "تلاش دوباره"
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceFigure, {
							toman: tether?.toman ?? null,
							delta: history.engine.lastPriceToman != null && tether ? tether.toman - history.engine.lastPriceToman : tether?.change ?? null
						}),
						chartData.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 h-28",
							dir: "ltr",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
									data: chartData,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
											id: "pfill",
											x1: "0",
											y1: "0",
											x2: "0",
											y2: "1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
												offset: "0%",
												stopColor: "var(--color-up)",
												stopOpacity: .28
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
												offset: "100%",
												stopColor: "var(--color-up)",
												stopOpacity: 0
											})]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
											contentStyle: {
												background: "#141612",
												border: "1px solid #2a2c27",
												borderRadius: 8,
												fontSize: 12
											},
											formatter: (v) => [`${Number(v).toLocaleString("en-US")} تومان`, "تتر"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
											type: "monotone",
											dataKey: "p",
											stroke: "var(--color-up)",
											fill: "url(#pfill)",
											strokeWidth: 1.6,
											dot: false
										})
									]
								})
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-xs text-faint",
							children: "بعد از چند اجرا، روند قیمت همین‌جا رسم می‌شود."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "flex flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "پیش‌نمایش پیامک" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
							className: "mt-1 mb-4",
							children: "همان متنی که به موبایل می‌رسد — فقط تتر، اختلاف، ساعت تهران."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmsPhone, { text: lastSms })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "پیامک امروز",
						value: `${history.quota.sentCount} / ${settings.dailyLimit}`,
						hint: `${remaining} باقی‌مانده`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "نوبت بعدی",
						value: upcoming[0] ? upcoming[0].slot : "—",
						hint: upcoming[0]?.dayOffset === 1 ? "فردا · تهران" : "امروز · تهران"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "دلار آزاد",
						value: market && market.ok && market.dollar ? formatToman(market.dollar.toman) : "—",
						hint: "نمایش؛ پیامک نمی‌شود"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "آخرین وضعیت",
						value: statusFa(lastJob?.status),
						hint: lastJob?.reason ?? "هنوز اجرایی نبوده"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "زمان‌بندی امروز" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-faint",
					children: "پنجره هر نوبت ۱۸ دقیقه"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: settings.slots.map((slot) => {
					const done = history.quota.slotsSent.includes(slot);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("rounded-md border px-3 py-2 text-sm tabular-nums", done ? "border-up/30 bg-up/10 text-up" : "border-border text-muted"),
						children: slot
					}, slot);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "گزارش اجرا" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
					className: "mt-1 mb-4",
					children: "خطاها ثبت می‌شوند و اجرای بعدی مستقل ادامه پیدا می‌کند. کلید و شماره در لاگ نیست."
				}),
				history.jobs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "هنوز اجرایی ثبت نشده. «اجرای آزمایشی» را بزنید تا مسیر کامل تست شود."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: history.jobs.slice(0, 12).map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [statusFa(job.status), job.priceToman != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ms-2 tabular-nums text-muted",
								children: [formatToman(job.priceToman), " تومان"]
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: job.reason
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tabular-nums text-faint",
							children: [
								tehranParts(new Date(job.startedAt)).hhmm,
								job.slot ? ` · ${job.slot}` : "",
								job.smsStatus ? ` · ${smsFa(job.smsStatus)}` : ""
							]
						})]
					}, job.id))
				})
			] })
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xl font-medium tabular-nums tracking-tight",
			children: value
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-faint",
			children: hint
		})
	] });
}
function statusFa(s) {
	if (s === "ok") return "موفق";
	if (s === "skip") return "رد شد";
	if (s === "error") return "خطا";
	return "نامشخص";
}
function smsFa(s) {
	if (s === "sent") return "ارسال شد";
	if (s === "dry-run") return "آزمایشی";
	if (s === "failed") return "خطای پیامک";
	if (s === "not-configured") return "بدون پیکربندی";
	return "ارسال نشد";
}
//#endregion
export { Dashboard as component };
