import { a as extractTetherPrice, f as smsFromEnv, i as executeJob, o as fetchMarket, p as tehranClock, r as createPgStore, s as formatSms, t as DEFAULT_SLOTS } from "./pg-store.server-Dm1BeILm.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as number, n as array, o as object, r as boolean, s as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-cUkDbGPn.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var smsSchema = object({
	provider: _enum([
		"kavenegar",
		"melipayamak",
		"smsir",
		"custom"
	]),
	apiUrl: string(),
	apiKey: string(),
	to: string(),
	from: string().optional(),
	username: string().optional()
}).nullable();
var getMarketFn_createServerFn_handler = createServerRpc({
	id: "5050535fbd3c98805a99304e62f2573f48b0747ec45501721b4bce3c14e2d4f8",
	name: "getMarketFn",
	filename: "src/lib/functions.ts"
}, (opts) => getMarketFn.__executeServer(opts));
var getMarketFn = createServerFn({ method: "GET" }).handler(getMarketFn_createServerFn_handler, async () => {
	return fetchMarket();
});
var getHistoryFn_createServerFn_handler = createServerRpc({
	id: "3af889fca7db64f67ff99de03c2e46f2f9b6dc42e4cc4d6dcf7ac175d98ba926",
	name: "getHistoryFn",
	filename: "src/lib/functions.ts"
}, (opts) => getHistoryFn.__executeServer(opts));
var getHistoryFn = createServerFn({ method: "GET" }).handler(getHistoryFn_createServerFn_handler, async () => {
	const store = await createPgStore();
	const [jobs, ticks, engine] = await Promise.all([
		store.recentJobs(30),
		store.recentTicks(48),
		store.getEngineState()
	]);
	const { tehranParts } = await import("./pg-store.server-Dm1BeILm.mjs").then((n) => n.d).then((n) => n.d);
	return {
		jobs,
		ticks,
		engine,
		quota: await store.getQuota(tehranParts().dayKey)
	};
});
var parseTextFn_createServerFn_handler = createServerRpc({
	id: "f68e0742608e4d38b609d667e448ef34ddc61414b3b2af4bd021c5405d0ea266",
	name: "parseTextFn",
	filename: "src/lib/functions.ts"
}, (opts) => parseTextFn.__executeServer(opts));
var parseTextFn = createServerFn({ method: "POST" }).validator(object({ text: string().max(8e3) })).handler(parseTextFn_createServerFn_handler, async ({ data }) => {
	const hit = extractTetherPrice(data.text);
	if (!hit) return {
		ok: false,
		error: "قیمت تتر پیدا نشد"
	};
	const smsText = formatSms({
		toman: hit.toman,
		delta: null,
		time: tehranClock()
	});
	return {
		ok: true,
		toman: hit.toman,
		matched: hit.matched,
		smsText
	};
});
var runJobFn_createServerFn_handler = createServerRpc({
	id: "2f06b8cd22e813063651c80facff5abc4bfd63be3d281dc609227ad7cfcbfcea",
	name: "runJobFn",
	filename: "src/lib/functions.ts"
}, (opts) => runJobFn.__executeServer(opts));
var runJobFn = createServerFn({ method: "POST" }).validator(object({
	force: boolean(),
	deliver: boolean(),
	slots: array(string()).max(24).optional(),
	dailyLimit: number().int().min(1).max(10).optional(),
	telegramText: string().max(8e3).optional(),
	telegramMessageId: string().max(64).optional(),
	sms: smsSchema.optional()
})).handler(runJobFn_createServerFn_handler, async ({ data }) => {
	const store = await createPgStore();
	const envSms = smsFromEnv({
		SMS_TO: process.env.SMS_TO,
		SMS_API_KEY: process.env.SMS_API_KEY,
		SMS_API_URL: process.env.SMS_API_URL,
		SMS_PROVIDER: process.env.SMS_PROVIDER,
		SMS_FROM: process.env.SMS_FROM,
		SMS_USERNAME: process.env.SMS_USERNAME
	});
	const sms = data.sms ?? envSms;
	return executeJob(store, {
		now: /* @__PURE__ */ new Date(),
		force: data.force,
		deliver: data.deliver,
		slots: data.slots?.length ? data.slots : [...DEFAULT_SLOTS],
		dailyLimit: data.dailyLimit ?? 10,
		sms,
		telegramText: data.telegramText,
		telegramMessageId: data.telegramMessageId
	});
});
//#endregion
export { getHistoryFn_createServerFn_handler, getMarketFn_createServerFn_handler, parseTextFn_createServerFn_handler, runJobFn_createServerFn_handler };
