import { o as __toESM } from "../_runtime.mjs";
import { f as smsFromEnv, i as executeJob, n as __exportAll, r as createPgStore, t as DEFAULT_SLOTS } from "./pg-store.server-Dm1BeILm.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as number, c as union, i as literal, n as array, o as object, r as boolean, s as string, t as _enum } from "../_libs/zod.mjs";
import { a as Activity, i as ScanSearch, n as TriangleAlert, r as Settings2, t as Waypoints } from "../_libs/lucide-react.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-D8Ec0NzO.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var smsSchema = object({
	provider: _enum([
		"kavenegar",
		"melipayamak",
		"smsir",
		"custom"
	]),
	apiUrl: string(),
	apiKey: string(),
	to: string(),
	from: string().optional(),
	username: string().optional()
}).nullable();
var getMarketFn = createServerFn({ method: "GET" }).handler(createSsrRpc("5050535fbd3c98805a99304e62f2573f48b0747ec45501721b4bce3c14e2d4f8"));
var getHistoryFn = createServerFn({ method: "GET" }).handler(createSsrRpc("3af889fca7db64f67ff99de03c2e46f2f9b6dc42e4cc4d6dcf7ac175d98ba926"));
createServerFn({ method: "POST" }).validator(object({ text: string().max(8e3) })).handler(createSsrRpc("f68e0742608e4d38b609d667e448ef34ddc61414b3b2af4bd021c5405d0ea266"));
var runJobFn = createServerFn({ method: "POST" }).validator(object({
	force: boolean(),
	deliver: boolean(),
	slots: array(string()).max(24).optional(),
	dailyLimit: number().int().min(1).max(10).optional(),
	telegramText: string().max(8e3).optional(),
	telegramMessageId: string().max(64).optional(),
	sms: smsSchema.optional()
})).handler(createSsrRpc("2f06b8cd22e813063651c80facff5abc4bfd63be3d281dc609227ad7cfcbfcea"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-B4EFIl9N.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "خطای پیش‌بینی‌نشده. صفحه را دوباره بارگذاری کنید.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-down",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "مشکلی پیش آمد"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function AppProviders({ children }) {
	const [client] = (0, import_react.useState)(() => new QueryClient({ defaultOptions: { queries: {
		staleTime: 2e4,
		refetchOnWindowFocus: false
	} } }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			dir: "rtl",
			theme: "dark",
			position: "top-center",
			toastOptions: { style: {
				background: "#141612",
				color: "#e8ebe4",
				border: "1px solid #2a2c27",
				fontFamily: "Vazirmatn, sans-serif"
			} }
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var NAV = [
	{
		to: "/",
		label: "داشبورد",
		icon: Activity
	},
	{
		to: "/parser",
		label: "استخراج",
		icon: ScanSearch
	},
	{
		to: "/settings",
		label: "تنظیمات",
		icon: Settings2
	},
	{
		to: "/architecture",
		label: "معماری",
		icon: Waypoints
	}
];
function AppShell() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh max-w-[1200px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-[220px] shrink-0 flex-col border-e border-border p-5 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] tracking-[0.18em] text-faint",
								children: "NERKHRESAN"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 text-lg font-semibold tracking-tight",
								children: "نرخ‌رسان"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs leading-5 text-muted",
								children: "اتوماسیون قیمت تتر"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1",
						children: NAV.map((item) => {
							const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("flex h-11 items-center gap-2.5 rounded-md px-3 text-sm transition-colors duration-150", active ? "bg-bg-subtle text-fg" : "text-muted hover:bg-bg-subtle hover:text-fg"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									strokeWidth: 1.75
								}), item.label]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] leading-5 text-faint",
						children: [
							"سقف ۱۰ پیامک در روز",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"زمان تهران"
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col pb-20 md:pb-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "flex items-center justify-between border-b border-border px-4 py-3 md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] tracking-[0.18em] text-faint",
						children: "NERKHRESAN"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "نرخ‌رسان"
					})] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 px-4 py-5 sm:px-6 sm:py-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 backdrop-blur md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4",
				children: NAV.map((item) => {
					const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("flex h-16 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-fg" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							strokeWidth: 1.75
						}), item.label]
					}, item.to);
				})
			})
		})]
	});
}
var styles_default = "/assets/styles-BBX6r1rU.css";
var APP_NAME = "نرخ‌رسان";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "اتوماسیون دریافت نرخ تتر و ارسال پیامک، بدون اکانت شخصی تلگرام"
			},
			{
				name: "theme-color",
				content: "#0c0d0b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fa",
		dir: "rtl",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppProviders, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$2 = () => import("./routes-BOlZF4VW.mjs");
var Route$5 = createFileRoute("/")({
	loader: async () => {
		const [market, history] = await Promise.all([getMarketFn(), getHistoryFn()]);
		return {
			market,
			history
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl border border-border bg-bg-elevated p-4 shadow-[var(--shadow-soft)] sm:p-5", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("text-sm font-medium tracking-tight text-fg", className),
		...props
	});
}
function CardHint({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm leading-relaxed text-muted", className),
		...props
	});
}
var Route$4 = createFileRoute("/architecture")({ component: ArchitecturePage });
function ArchitecturePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight",
				children: "معماری نهایی"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm leading-6 text-muted",
				children: "معماری اولیه (بات تلگرام در گروه، ارسال «نرخ ارز»، خواندن پاسخ ربات دیگر) پیاده نشد؛ محدودیت واقعی تلگرام آن را ناپایدار می‌کند. هدف شما حفظ شده: نرخ تتر همان بازار آزاد، استخراج، پیامک خودکار، بدون اکانت شخصی، حداکثر ۱۰ پیامک در روز."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "چرا مسیر بات‌به‌بات گروه کار نمی‌کند" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-3 text-sm leading-7 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "طبق FAQ رسمی تلگرام، بات‌ها پیام بات دیگر را نمی‌بینند تا حلقه پیش نیاید. از مه ۲۰۲۶ حالت Bot-to-Bot اضافه شده، اما:" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "list-disc space-y-1 ps-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ربات نرخ ارز باید پیام بات شما («نرخ ارز») را ببیند. این تنظیم روی ربات آن‌هاست و در کنترل شما نیست." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "حتی اگر بات شما ادمین باشد و Privacy را خاموش کند، تریگر همچنان به همکاری ربات مقابل وابسته است." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "انتظار برای پاسخ روی ورکر بدون حالت، شکننده است: تأخیر، پیام نامرتبط، قطعی API." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "اکانت شخصی طبق الزام شما کنار گذاشته شد. Userbot جدا هم نیاز به شماره و اتصال پایدار دارد و روی Cloudflare Worker مناسب نیست." })
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "معماری انتخاب‌شده" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 overflow-x-auto rounded-md bg-bg p-4 text-xs leading-6 text-muted",
					dir: "ltr",
					children: `Cron هر ۱۵ دقیقه
    ↓
بررسی ساعت تهران با نوبت‌های قابل تنظیم
    ↓
TGJU (بازار آزاد)  →  استخراج تتر
    ↓
سقف روزانه + جلوگیری از تکرار نوبت
    ↓
قالب پیامک   →   پنل SMS
    ↓
ثبت گزارش بدون کلید و شماره`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-7 text-muted",
					children: "TGJU همان منبعی است که اکثر ربات‌های «نرخ ارز» از آن می‌خوانند. دلار آزاد و تتر نمونه‌تان با همین منبع هم‌خوان است. دقت بالا، بدون گروه، بدون اکانت شخصی، روی ورکر یا همین اپ پایدار است."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "مسیر تلگرام — اختیاری" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
					className: "mt-2 leading-7",
					children: "اگر ربات نرخ در کانال یا گروه به‌صورت خودکار پست می‌کند، بات خودتان را ادمین کنید، Privacy را خاموش کنید، Bot-to-Bot را روشن کنید و وب‌هوک `/api/telegram` را بگذارید. سیستم پیام را پارس می‌کند؛ اگر تتر نباشد پیامک نمی‌رود. ارسال «نرخ ارز» از طرف بات شما عمداً پیش‌فرض نیست."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "اولویت‌ها" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-2 list-decimal space-y-1 ps-5 text-sm leading-7 text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "دقت نرخ بازار آزاد" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "پایداری و اجرای مستقل بعد از خطا" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "بدون اکانت شخصی تلگرام" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "کاملاً خودکار با کرون" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "کلیدها در Secret، نه در سورس" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "سقف ۱۰ پیامک حتی با اجرای مجدد" })
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "راهنمای راه‌اندازی" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-4 text-sm leading-7 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium text-fg",
						children: "۱. تست همین‌جا"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "داشبورد نرخ زنده را نشان می‌دهد. «اجرای آزمایشی» مسیر را بدون پیامک طی می‌کند. در صفحه استخراج، متن ربات را پارس کنید." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium text-fg",
						children: "۲. اتصال پیامک"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"در",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							className: "text-fg underline-offset-4 hover:underline",
							children: "تنظیمات"
						}),
						" ",
						"پنل را انتخاب کنید، شماره و کلید را بگذارید، حالت آزمایش را خاموش کنید. اگر مستندات واقعی پنل را بفرستید، آداپتر دقیق همان پنل اضافه می‌شود."
					] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium text-fg",
						children: "۳. زمان‌بندی و شماره"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "نوبت‌ها و سقف روزانه از تنظیمات عوض می‌شوند. شماره فقط در فیلد «گیرنده» یا متغیر SMS_TO است." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium text-fg",
						children: "۴. استقرار خودکار"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "همین اپ با مسیر `/api/cron` هر ۱۵ دقیقه نوبت تهران را چک می‌کند. هدر `X-Cron-Secret` را با CRON_SECRET بگذارید. جایگزین Cloudflare: پوشه worker با wrangler، KV برای وضعیت، همان موتور نرخ و پیامک." })] })
				]
			})] })
		]
	});
}
var $$splitComponentImporter$1 = () => import("./parser-CFSmE7QP.mjs");
var Route$3 = createFileRoute("/parser")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./settings-C97F2NA_.mjs");
var Route$2 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
async function handle({ request }) {
	const secret = process.env.CRON_SECRET?.trim();
	const given = request.headers.get("x-cron-secret") ?? new URL(request.url).searchParams.get("secret") ?? "";
	if (secret && given !== secret) return Response.json({
		ok: false,
		error: "unauthorized"
	}, { status: 401 });
	const store = await createPgStore();
	const sms = smsFromEnv({
		SMS_TO: process.env.SMS_TO,
		SMS_API_KEY: process.env.SMS_API_KEY,
		SMS_API_URL: process.env.SMS_API_URL,
		SMS_PROVIDER: process.env.SMS_PROVIDER,
		SMS_FROM: process.env.SMS_FROM,
		SMS_USERNAME: process.env.SMS_USERNAME
	});
	const slots = (process.env.SCHEDULE_SLOTS ?? DEFAULT_SLOTS.join(",")).split(",").map((s) => s.trim()).filter(Boolean);
	if ((process.env.PRICE_SOURCE?.trim() || "tgju") === "telegram") return Response.json({
		ok: true,
		skipped: true,
		reason: "telegram-listen-mode"
	});
	const job = await executeJob(store, {
		now: /* @__PURE__ */ new Date(),
		force: false,
		deliver: Boolean(sms) && process.env.SMS_DRY_RUN !== "1",
		slots,
		dailyLimit: Math.min(10, Math.max(1, Number(process.env.DAILY_LIMIT) || 10)),
		sms
	});
	return Response.json({
		ok: job.status !== "error",
		status: job.status,
		reason: job.reason,
		priceToman: job.priceToman,
		slot: job.slot,
		smsStatus: job.smsStatus
	});
}
var Route$1 = createFileRoute("/api/cron")({ server: { handlers: {
	GET: handle,
	POST: handle
} } });
function extractTelegramText(update) {
	const msg = update.message ?? update.channel_post;
	if (!msg) return null;
	const text = (msg.text ?? msg.caption ?? "").trim();
	if (!text) return null;
	const fromBot = Boolean(update.message?.from?.is_bot);
	return {
		text,
		messageId: String(msg.message_id),
		fromBot,
		chatId: msg.chat?.id != null ? String(msg.chat.id) : null
	};
}
var Route = createFileRoute("/api/telegram")({ server: { handlers: { POST: async ({ request }) => {
	const secret = process.env.TELEGRAM_WEBHOOK_SECRET?.trim();
	const header = request.headers.get("x-telegram-bot-api-secret-token");
	const query = new URL(request.url).searchParams.get("secret");
	if (secret && header !== secret && query !== secret) return Response.json({ ok: false }, { status: 401 });
	let update;
	try {
		update = await request.json();
	} catch {
		return Response.json({ ok: false }, { status: 400 });
	}
	const extracted = extractTelegramText(update);
	if (!extracted) return Response.json({
		ok: true,
		ignored: true
	});
	const store = await createPgStore();
	const sms = smsFromEnv({
		SMS_TO: process.env.SMS_TO,
		SMS_API_KEY: process.env.SMS_API_KEY,
		SMS_API_URL: process.env.SMS_API_URL,
		SMS_PROVIDER: process.env.SMS_PROVIDER,
		SMS_FROM: process.env.SMS_FROM,
		SMS_USERNAME: process.env.SMS_USERNAME
	});
	const job = await executeJob(store, {
		now: /* @__PURE__ */ new Date(),
		force: true,
		deliver: Boolean(sms) && process.env.SMS_DRY_RUN !== "1",
		slots: [...DEFAULT_SLOTS],
		dailyLimit: Math.min(10, Math.max(1, Number(process.env.DAILY_LIMIT) || 10)),
		sms,
		telegramText: extracted.text,
		telegramMessageId: extracted.messageId
	});
	return Response.json({
		ok: true,
		status: job.status,
		reason: job.reason
	});
} } } });
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	ArchitectureRoute: Route$4.update({
		id: "/architecture",
		path: "/architecture",
		getParentRoute: () => Route$6
	}),
	ParserRoute: Route$3.update({
		id: "/parser",
		path: "/parser",
		getParentRoute: () => Route$6
	}),
	SettingsRoute: Route$2.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$6
	}),
	ApiCronRoute: Route$1.update({
		id: "/api/cron",
		path: "/api/cron",
		getParentRoute: () => Route$6
	}),
	ApiTelegramRoute: Route.update({
		id: "/api/telegram",
		path: "/api/telegram",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$5 as a, getMarketFn as c, CardTitle as i, runJobFn as l, Card as n, cn as o, CardHint as r, getHistoryFn as s, router_exports as t };
