import { o as __toESM } from "../_runtime.mjs";
import { a as extractTetherPrice, c as formatToman, p as tehranClock, s as formatSms } from "./pg-store.server-Dm1BeILm.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as CardTitle, l as runJobFn, n as Card, r as CardHint } from "./router-B4EFIl9N.mjs";
import { r as SmsPhone, t as Badge } from "./sms-phone-Dl_77uNp.mjs";
import { n as settingsToSms, r as useSettings, t as Button } from "./settings-D6uC_Qvm.mjs";
import { r as Textarea } from "./input-BylOHLpp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/parser-CFSmE7QP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SAMPLE = `◄ نرخ ارز و طلا در بازار آزاد :

• تاریخ : دوشنبه ۲۳ شهریور ۱۴۰۵
• ساعت : ۱۹:۴۱

🇺🇸 دلار : 232,085 تومان
🇪🇺 یورو : 268,970 تومان

◄ قیمت ارزهای دیجیتال:

💵 تتر : 229,852 تومان
💰 بیتکوین : 78,471.19 دلار
💰 اتریوم : 2,505.8 دلار`;
function ParserPage() {
	const [text, setText] = (0, import_react.useState)(SAMPLE);
	const [running, setRunning] = (0, import_react.useState)(false);
	const settings = useSettings();
	const hit = (0, import_react.useMemo)(() => extractTetherPrice(text), [text]);
	const sms = hit ? formatSms({
		toman: hit.toman,
		delta: 1250,
		time: tehranClock()
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: "آزمایش استخراج"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm leading-6 text-muted",
			children: "پیام ربات نرخ ارز را اینجا بچسبانید. استخراج به شماره خط وابسته نیست و فاصله یا دونقطه را تحمل می‌کند. اگر قیمت پیدا نشود، پیامک ارسال نمی‌شود."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[1.2fr_0.8fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "متن ورودی" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
					className: "mt-1 mb-3",
					children: "نمونه ربات از قبل آمده؛ می‌توانید عوضش کنید."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: text,
					onChange: (e) => setText(e.target.value),
					spellCheck: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setText(SAMPLE),
						children: "بازگردانی نمونه"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						disabled: !hit || running,
						onClick: async () => {
							setRunning(true);
							try {
								const job = await runJobFn({ data: {
									force: true,
									deliver: false,
									telegramText: text,
									telegramMessageId: `parser-${Date.now()}`,
									slots: settings.slots,
									dailyLimit: settings.dailyLimit,
									sms: settingsToSms(settings)
								} });
								toast(job.reason ?? job.status);
							} catch {
								toast("اجرا ناموفق بود");
							} finally {
								setRunning(false);
							}
						},
						children: "اجرای مسیر کامل"
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "نتیجه" }), hit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "up",
							children: "پیدا شد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-2xl font-semibold tabular-nums",
							children: [
								formatToman(hit.toman),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-muted",
									children: "تومان"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-faint",
							children: ["تطبیق: ", hit.matched]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "down",
						children: "قیمت تتر پیدا نشد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "پیامک در این حالت ارسال نمی‌شود و خطا فقط در گزارش می‌ماند."
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "پیامک تولیدی" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmsPhone, {
						text: sms,
						emptyHint: "بدون قیمت، متنی ساخته نمی‌شود"
					})
				})] })]
			})]
		})]
	});
}
//#endregion
export { ParserPage as component };
