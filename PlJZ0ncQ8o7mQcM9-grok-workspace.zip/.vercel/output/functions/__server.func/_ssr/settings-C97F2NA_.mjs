import { t as DEFAULT_SLOTS, u as normalizeSlot } from "./pg-store.server-Dm1BeILm.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as CardTitle, n as Card, o as cn, r as CardHint } from "./router-B4EFIl9N.mjs";
import { r as useSettings, t as Button } from "./settings-D6uC_Qvm.mjs";
import { n as Label, t as Input } from "./input-BylOHLpp.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-C97F2NA_.js
var import_jsx_runtime = require_jsx_runtime();
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-11 shrink-0 items-center rounded-full border border-border bg-bg-subtle transition-colors data-[state=checked]:bg-accent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-0.5 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-[22px] data-[state=checked]:bg-accent-fg" })
	});
}
var PROVIDERS = [
	{
		id: "kavenegar",
		label: "کاوه‌نگار",
		hint: "API Key در مسیر URL"
	},
	{
		id: "melipayamak",
		label: "ملی‌پیامک",
		hint: "نام کاربری + رمز"
	},
	{
		id: "smsir",
		label: "SMS.ir",
		hint: "هدر X-API-KEY"
	},
	{
		id: "custom",
		label: "دلخواه",
		hint: "POST JSON با to و message"
	}
];
function SettingsPage() {
	const s = useSettings();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight",
				children: "تنظیمات"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm leading-6 text-muted",
				children: "کلیدها روی همین دستگاه ذخیره می‌شوند، نه در کد. در استقرار نهایی از Secretهای سرور استفاده کنید تا در مرورگر نمانند."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "حالت آزمایش" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
					className: "mt-1",
					children: "روشن بماند تا وقتی API پیامک را تست نکرده‌اید. سقف روزانه در هر دو حالت رعایت می‌شود."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					dir: "ltr",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: s.dryRun,
						onCheckedChange: (v) => s.set({ dryRun: v }),
						"aria-label": "حالت آزمایش"
					})
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "منبع نرخ" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
					className: "mt-1 mb-4",
					children: "پیشنهاد ما TGJU است. تلگرام فقط اگر ربات نرخ در کانال/گروه به‌صورت خودکار پست کند و بات شما ادمین باشد."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [["tgju", "TGJU — بازار آزاد"], ["telegram", "تلگرام — شنونده اختیاری"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => s.set({ priceSource: id }),
						className: `h-11 rounded-md border px-3 text-start text-sm ${s.priceSource === id ? "border-accent bg-bg-subtle text-fg" : "border-border text-muted"}`,
						children: label
					}, id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "پیامک" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
					className: "mt-1 mb-4",
					children: "شماره، آدرس API و کلید را پر کنید. کلید در لاگ چاپ نمی‌شود."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 flex flex-wrap gap-2",
					children: PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => s.set({ smsProvider: p.id }),
						className: `rounded-full border px-3 py-1.5 text-xs ${s.smsProvider === p.id ? "border-accent bg-bg-subtle text-fg" : "border-border text-muted"}`,
						children: p.label
					}, p.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "شماره گیرنده",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: s.smsTo,
								onChange: (e) => s.set({ smsTo: e.target.value }),
								placeholder: "0912…",
								inputMode: "tel",
								autoComplete: "off"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "کلید API",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								value: s.smsApiKey,
								onChange: (e) => s.set({ smsApiKey: e.target.value }),
								placeholder: "در کد سخت نمی‌شود",
								autoComplete: "off"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "آدرس API (اختیاری)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: s.smsApiUrl,
								onChange: (e) => s.set({ smsApiUrl: e.target.value }),
								placeholder: "خالی = پیش‌فرض پنل",
								dir: "ltr"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "خط ارسال / از",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: s.smsFrom,
								onChange: (e) => s.set({ smsFrom: e.target.value }),
								dir: "ltr"
							})
						}),
						s.smsProvider === "melipayamak" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "نام کاربری ملی‌پیامک",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: s.smsUsername,
								onChange: (e) => s.set({ smsUsername: e.target.value })
							})
						}) : null
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "زمان‌بندی" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
						className: "mt-1",
						children: "حداکثر ۱۰ نوبت در روز · ساعت تهران"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => s.set({ slots: [...DEFAULT_SLOTS] }),
						children: "پیش‌فرض"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: s.slots.map((slot, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "time",
						value: slot,
						onChange: (e) => {
							const next = normalizeSlot(e.target.value);
							if (!next) return;
							const slots = [...s.slots];
							slots[i] = next;
							s.set({ slots });
						},
						className: "h-11 rounded-md border border-border bg-bg px-3 text-sm tabular-nums text-fg"
					}, `${slot}-${i}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: s.slots.length >= 10,
						onClick: () => s.set({ slots: [...s.slots, "12:00"] }),
						children: "افزودن نوبت"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						disabled: s.slots.length <= 1,
						onClick: () => s.set({ slots: s.slots.slice(0, -1) }),
						children: "حذف آخرین"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "سقف روزانه",
					className: "mt-4 max-w-40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 1,
						max: 10,
						value: s.dailyLimit,
						onChange: (e) => s.set({ dailyLimit: Math.min(10, Math.max(1, Number(e.target.value) || 1)) })
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "متغیرهای سرور (استقرار)" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
					className: "mt-1 mb-3",
					children: "این نام‌ها را در Secrets بگذارید — هرگز داخل سورس."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-1 font-mono text-xs leading-6 text-muted",
					dir: "ltr",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "SMS_API_URL" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "SMS_API_KEY" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "SMS_TO" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "SMS_PROVIDER" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "CRON_SECRET" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "TELEGRAM_BOT_TOKEN" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "TELEGRAM_WEBHOOK_SECRET" })
					]
				})
			] })
		]
	});
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
//#endregion
export { SettingsPage as component };
