import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as cn } from "./router-B4EFIl9N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-BylOHLpp.js
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-faint focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-40 w-full rounded-md border border-border bg-bg px-3 py-3 text-sm leading-relaxed text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-faint focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-1.5 block text-xs font-medium text-muted", className),
		...props
	});
}
//#endregion
export { Label as n, Textarea as r, Input as t };
