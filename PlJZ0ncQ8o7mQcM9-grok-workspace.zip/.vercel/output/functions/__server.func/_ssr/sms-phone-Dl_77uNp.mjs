import { c as formatToman } from "./pg-store.server-Dm1BeILm.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as cn } from "./router-B4EFIl9N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sms-phone-Dl_77uNp.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "neutral", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium", tone === "neutral" && "bg-bg-subtle text-muted", tone === "up" && "bg-up/15 text-up", tone === "down" && "bg-down/15 text-down", tone === "warn" && "bg-warn/15 text-warn", className),
		...props
	});
}
function SmsPhone({ text, emptyHint = "هنوز پیامکی ساخته نشده" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto w-full max-w-[280px]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-[28px] border border-border-strong bg-bg p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[20px] bg-bg-subtle px-3 pb-4 pt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1.5 w-16 rounded-full bg-border-strong" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-center text-[10px] text-faint",
						children: "پیامک · نرخ‌رسان"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg rounded-ss-sm bg-bg-elevated px-3 py-3",
						children: text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "whitespace-pre-wrap font-sans text-[13px] leading-6 text-fg",
							children: text
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-6 text-muted",
							children: emptyHint
						})
					})
				]
			})
		})
	});
}
function PriceFigure({ toman, delta }) {
	if (toman == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-3xl font-medium text-muted",
		children: "—"
	});
	const up = (delta ?? 0) > 0;
	const down = (delta ?? 0) < 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-[clamp(2.4rem,6vw,3.6rem)] font-semibold leading-none tracking-tight tabular-nums",
		children: [formatToman(toman), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "ms-2 text-base font-medium text-muted",
			children: "تومان"
		})]
	}), delta != null && delta !== 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: `mt-3 text-sm tabular-nums ${up ? "text-up" : down ? "text-down" : "text-muted"}`,
		children: [
			up ? "+" : "",
			formatToman(delta),
			" نسبت به ارسال قبلی"
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-3 text-sm text-muted",
		children: "اولین نرخ ثبت‌شده در این نشست"
	})] });
}
//#endregion
export { PriceFigure as n, SmsPhone as r, Badge as t };
