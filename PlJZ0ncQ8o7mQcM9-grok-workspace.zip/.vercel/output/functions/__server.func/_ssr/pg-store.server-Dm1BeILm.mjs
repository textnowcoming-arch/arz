import { r as __exportAll$1 } from "../_runtime.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pg-store.server-Dm1BeILm.js
var pg_store_server_Dm1BeILm_exports = /* @__PURE__ */ __exportAll$1({
	a: () => extractTetherPrice,
	c: () => DEFAULT_SLOTS,
	d: () => schedule_exports,
	f: () => tehranClock,
	h: () => __exportAll,
	i: () => smsFromEnv,
	l: () => nextSlots,
	m: () => tehranParts,
	n: () => executeJob,
	o: () => formatSms,
	p: () => tehranFaDate,
	r: () => fetchMarket,
	s: () => formatToman,
	t: () => createPgStore,
	u: () => normalizeSlot
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var schedule_exports = /* @__PURE__ */ __exportAll({
	DEFAULT_SLOTS: () => DEFAULT_SLOTS,
	SLOT_WINDOW_MIN: () => 18,
	TEHRAN_TZ: () => TEHRAN_TZ,
	matchSlot: () => matchSlot,
	minutesOf: () => minutesOf,
	nextSlots: () => nextSlots,
	normalizeSlot: () => normalizeSlot,
	tehranClock: () => tehranClock,
	tehranFaDate: () => tehranFaDate,
	tehranParts: () => tehranParts
});
var TEHRAN_TZ = "Asia/Tehran";
var DEFAULT_SLOTS = [
	"08:00",
	"10:00",
	"12:00",
	"14:00",
	"16:00",
	"18:00",
	"19:00",
	"20:00",
	"21:00",
	"22:00"
];
function tehranParts(now = /* @__PURE__ */ new Date()) {
	const fmt = new Intl.DateTimeFormat("en-GB", {
		timeZone: TEHRAN_TZ,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23"
	});
	const map = {};
	for (const part of fmt.formatToParts(now)) if (part.type !== "literal") map[part.type] = part.value;
	const hour = Number(map.hour);
	const minute = Number(map.minute);
	return {
		dayKey: `${map.year}-${map.month}-${map.day}`,
		year: Number(map.year),
		month: Number(map.month),
		day: Number(map.day),
		hour,
		minute,
		hhmm: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`
	};
}
function tehranClock(now = /* @__PURE__ */ new Date()) {
	return tehranParts(now).hhmm;
}
function tehranFaDate(now = /* @__PURE__ */ new Date()) {
	return new Intl.DateTimeFormat("fa-IR", {
		timeZone: TEHRAN_TZ,
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(now);
}
function minutesOf(hhmm) {
	const [h, m] = hhmm.split(":").map((x) => Number(x));
	if (!Number.isFinite(h) || !Number.isFinite(m)) return NaN;
	return h * 60 + m;
}
function normalizeSlot(raw) {
	const n = raw.trim();
	const m = /^(\d{1,2}):(\d{2})$/.exec(n);
	if (!m) return null;
	const h = Number(m[1]);
	const min = Number(m[2]);
	if (h < 0 || h > 23 || min < 0 || min > 59) return null;
	return `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}`;
}
function matchSlot(now, slots, windowMin = 18) {
	const t = tehranParts(now);
	const nowMin = t.hour * 60 + t.minute;
	let best = null;
	for (const slot of slots) {
		const s = minutesOf(slot);
		if (!Number.isFinite(s)) continue;
		const delta = nowMin - s;
		if (delta >= 0 && delta <= windowMin) {
			if (!best || delta < best.delta) best = {
				slot,
				delta
			};
		}
	}
	return best?.slot ?? null;
}
function nextSlots(now, slots, count = 3) {
	const t = tehranParts(now);
	const nowMin = t.hour * 60 + t.minute;
	const ordered = [...slots].filter((s) => Number.isFinite(minutesOf(s)));
	ordered.sort((a, b) => minutesOf(a) - minutesOf(b));
	const out = [];
	for (const slot of ordered) {
		if (minutesOf(slot) >= nowMin) out.push({
			slot,
			dayOffset: 0
		});
		if (out.length >= count) return out;
	}
	for (const slot of ordered) {
		out.push({
			slot,
			dayOffset: 1
		});
		if (out.length >= count) return out;
	}
	return out;
}
function formatToman(n) {
	return Math.round(n).toLocaleString("en-US");
}
function formatSms(opts) {
	const lines = [`💵 تتر: ${formatToman(opts.toman)} تومان`];
	if (opts.delta != null && opts.delta !== 0) {
		const up = opts.delta > 0;
		const arrow = up ? "📈" : "📉";
		const sign = up ? "+" : "-";
		lines.push(`${arrow} ${sign}${formatToman(Math.abs(opts.delta))} تومان`);
	}
	lines.push(`🕐 ${opts.time}`);
	return lines.join("\n");
}
async function sha256hex(value) {
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
	return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function newId() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
var FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
var AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";
function normalizeDigits(input) {
	let out = "";
	for (const ch of input) {
		const fa = FA_DIGITS.indexOf(ch);
		if (fa >= 0) {
			out += String(fa);
			continue;
		}
		const ar = AR_DIGITS.indexOf(ch);
		if (ar >= 0) {
			out += String(ar);
			continue;
		}
		out += ch;
	}
	return out;
}
/** Strip thousand separators; keep a trailing decimal only if it looks like cents. */
function parseAmount(raw) {
	const normalized = normalizeDigits(raw).replace(/[٬،\s]/g, "").replace(/,/g, "").trim();
	if (!normalized) return null;
	let cleaned = normalized;
	if (/^\d{1,3}(\.\d{3})+$/.test(cleaned)) cleaned = cleaned.replace(/\./g, "");
	else if (/^\d+\.\d{3,}$/.test(cleaned)) cleaned = cleaned.replace(/\./g, "");
	if (!/^\d+(\.\d+)?$/.test(cleaned)) return null;
	const value = Number(cleaned);
	if (!Number.isFinite(value) || value <= 0) return null;
	return Math.round(value);
}
var TETHER_PATTERNS = [
	/(?:💵|💲)?\s*تتر(?:\s*\(?\s*usdt\s*\)?)?\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال)?/i,
	/(?:قیمت\s*)?تتر\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال)?/i,
	/\busdt\b\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال|toman)?/i,
	/\btether\b\s*[:：=\-]?\s*([\d.,٬،\s]+)\s*(تومان|تومن|ریال|toman)?/i
];
var TOMAN_MIN = 1e3;
var TOMAN_MAX = 2e7;
function extractTetherPrice(text) {
	if (!text || typeof text !== "string") return null;
	const haystack = normalizeDigits(text).replace(/\u200c/g, " ");
	for (const pattern of TETHER_PATTERNS) {
		const match = new RegExp(pattern.source, pattern.flags).exec(haystack);
		if (!match?.[1]) continue;
		const amount = parseAmount(match[1]);
		if (amount == null) continue;
		const unitRaw = (match[2] ?? "").toLowerCase();
		let toman = amount;
		let unit = "toman";
		if (unitRaw === "ریال" || amount >= 1e6 && amount % 10 === 0) {
			if (unitRaw === "ریال" || amount >= 1e6) {
				toman = Math.round(amount / 10);
				unit = "rial";
			}
		}
		if (toman < TOMAN_MIN || toman > TOMAN_MAX) continue;
		return {
			toman,
			matched: match[0].trim(),
			unit
		};
	}
	return null;
}
function isValidTomanPrice(n) {
	return Number.isInteger(n) && n >= TOMAN_MIN && n <= TOMAN_MAX;
}
async function timedFetch(url, init, ms = 1e4) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), ms);
	try {
		return await fetch(url, {
			...init,
			signal: ctrl.signal
		});
	} finally {
		clearTimeout(timer);
	}
}
async function sendSms(cfg, text) {
	if (!cfg.to.trim()) return {
		ok: false,
		error: "شماره گیرنده خالی است"
	};
	if (!text.trim()) return {
		ok: false,
		error: "متن پیامک خالی است"
	};
	try {
		if (cfg.provider === "kavenegar") {
			const key = cfg.apiKey.trim();
			if (!key) return {
				ok: false,
				error: "کلید کاوه‌نگار خالی است"
			};
			const base = cfg.apiUrl.trim() || `https://api.kavenegar.com/v1/${encodeURIComponent(key)}/sms/send.json`;
			const url = new URL(base);
			url.searchParams.set("receptor", cfg.to);
			url.searchParams.set("message", text);
			const res = await timedFetch(url.toString(), { method: "GET" });
			if (!res.ok) return {
				ok: false,
				error: `SMS HTTP ${res.status}`
			};
			return {
				ok: true,
				provider: "kavenegar"
			};
		}
		if (cfg.provider === "melipayamak") {
			const res = await timedFetch(cfg.apiUrl.trim() || "https://rest.payamak-panel.com/api/SendSMS/SendSMS", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					username: cfg.username ?? cfg.from ?? "",
					password: cfg.apiKey,
					to: cfg.to,
					from: cfg.from ?? "",
					text
				})
			});
			if (!res.ok) return {
				ok: false,
				error: `SMS HTTP ${res.status}`
			};
			return {
				ok: true,
				provider: "melipayamak"
			};
		}
		if (cfg.provider === "smsir") {
			const res = await timedFetch(cfg.apiUrl.trim() || "https://api.sms.ir/v1/send/bulk", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"X-API-KEY": cfg.apiKey
				},
				body: JSON.stringify({
					lineNumber: cfg.from ?? "",
					messageText: text,
					mobiles: [cfg.to]
				})
			});
			if (!res.ok) return {
				ok: false,
				error: `SMS HTTP ${res.status}`
			};
			return {
				ok: true,
				provider: "smsir"
			};
		}
		const url = cfg.apiUrl.trim();
		if (!url) return {
			ok: false,
			error: "آدرس API پیامک تنظیم نشده"
		};
		const res = await timedFetch(url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				...cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {}
			},
			body: JSON.stringify({
				to: cfg.to,
				message: text,
				from: cfg.from ?? ""
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `SMS HTTP ${res.status}`
		};
		return {
			ok: true,
			provider: "custom"
		};
	} catch (err) {
		if ((err instanceof Error ? err.name : "") === "AbortError") return {
			ok: false,
			error: "SMS timeout"
		};
		return {
			ok: false,
			error: "ارسال پیامک ناموفق بود"
		};
	}
}
function smsFromEnv(env) {
	const to = env.SMS_TO?.trim();
	const key = env.SMS_API_KEY?.trim();
	if (!to || !key) return null;
	const provider = env.SMS_PROVIDER?.trim() || "custom";
	return {
		provider: [
			"kavenegar",
			"melipayamak",
			"smsir",
			"custom"
		].includes(provider) ? provider : "custom",
		apiUrl: env.SMS_API_URL?.trim() ?? "",
		apiKey: key,
		to,
		from: env.SMS_FROM?.trim(),
		username: env.SMS_USERNAME?.trim()
	};
}
var TGJU_URLS = [
	"https://call5.tgju.org/ajax.json",
	"https://call3.tgju.org/ajax.json",
	"https://call1.tgju.org/ajax.json"
];
function parseNum(raw) {
	if (raw == null) return null;
	const n = Number(String(raw).replace(/,/g, "").trim());
	return Number.isFinite(n) ? n : null;
}
/** TGJU quotes rial. Convert to toman when the figure is clearly rial-scale. */
function rialToToman(rial) {
	if (rial >= 1e6) return Math.round(rial / 10);
	return Math.round(rial);
}
function quoteFrom(item, symbol, title, asTomanFromRial) {
	if (!item) return null;
	const raw = parseNum(item.p);
	if (raw == null || raw <= 0) return null;
	const toman = asTomanFromRial ? rialToToman(raw) : Math.round(raw);
	const changeRaw = parseNum(item.d);
	return {
		symbol,
		title,
		toman,
		change: changeRaw == null ? null : asTomanFromRial ? rialToToman(changeRaw) * (item.dt === "low" ? -1 : 1) : Math.round(changeRaw) * (item.dt === "low" ? -1 : 1),
		changePct: parseNum(item.dp),
		capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
		sourceTime: item.ts ?? item.t ?? null
	};
}
async function fetchJson(url, timeoutMs) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), timeoutMs);
	try {
		const res = await fetch(url, {
			signal: ctrl.signal,
			headers: {
				Accept: "application/json",
				"User-Agent": "NerkhResan/1.0 (price-automation)"
			}
		});
		if (!res.ok) throw new Error(`HTTP ${res.status}`);
		return await res.json();
	} finally {
		clearTimeout(timer);
	}
}
async function fetchTgjuMarket() {
	let lastError = "منبع نرخ در دسترس نیست";
	for (const url of TGJU_URLS) try {
		const current = (await fetchJson(url, 8e3)).current;
		if (!current) throw new Error("shape");
		const tether = quoteFrom(current["crypto-tether-irr"], "USDT", "تتر", true);
		if (!tether) throw new Error("no tether");
		return {
			ok: true,
			source: "tgju",
			fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
			tether,
			dollar: quoteFrom(current["price_dollar_rl"], "USD", "دلار", true),
			euro: quoteFrom(current["price_eur"], "EUR", "یورو", true),
			bitcoinUsd: parseNum(current["crypto-bitcoin"]?.p),
			ethereumUsd: parseNum(current["crypto-ethereum"]?.p)
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : "fetch failed";
	}
	return {
		ok: false,
		error: `خطا در دریافت نرخ از TGJU (${lastError})`
	};
}
var cache = {
	at: 0,
	value: null
};
var CACHE_MS = 2e4;
async function fetchMarket(opts) {
	const now = Date.now();
	if (!opts?.bypassCache && cache.value && now - cache.at < CACHE_MS) return cache.value;
	const value = await fetchTgjuMarket();
	cache.at = now;
	cache.value = value;
	return value;
}
function clockLine() {
	return tehranClock();
}
function log(lines, msg) {
	lines.push({
		t: clockLine(),
		msg
	});
}
async function executeJob(store, input) {
	const logs = [];
	const id = newId();
	const startedAt = input.now.toISOString();
	const parts = tehranParts(input.now);
	log(logs, "Job started");
	const finish = (patch) => ({
		id,
		startedAt,
		reason: null,
		source: null,
		priceToman: null,
		deltaToman: null,
		slot: null,
		smsStatus: null,
		smsText: null,
		logs,
		...patch
	});
	try {
		const quota = await store.getQuota(parts.dayKey);
		const engine = await store.getEngineState();
		const slot = input.force ? `manual-${parts.hhmm}` : matchSlot(input.now, input.slots);
		if (!input.force && !slot) {
			log(logs, "Outside schedule window — skip");
			const job = finish({
				status: "skip",
				reason: "خارج از پنجره زمان‌بندی",
				smsStatus: "skipped"
			});
			await store.recordJob(job);
			return job;
		}
		if (!input.force && slot && quota.slotsSent.includes(slot)) {
			log(logs, `Slot ${slot} already sent today — skip`);
			const job = finish({
				status: "skip",
				reason: "این نوبت امروز ارسال شده",
				slot,
				smsStatus: "skipped"
			});
			await store.recordJob(job);
			return job;
		}
		if (quota.sentCount >= input.dailyLimit) {
			log(logs, `Daily SMS cap ${input.dailyLimit} reached — skip`);
			const job = finish({
				status: "skip",
				reason: "سقف ۱۰ پیامک روزانه پر شده",
				slot,
				smsStatus: "skipped"
			});
			await store.recordJob(job);
			return job;
		}
		let toman;
		let source = "tgju";
		let messageHash = null;
		if (input.telegramText) {
			log(logs, "Parsing Telegram payload");
			const hit = extractTetherPrice(input.telegramText);
			if (!hit) {
				log(logs, "Tether price not found in message");
				const job = finish({
					status: "error",
					reason: "قیمت تتر در متن پیدا نشد",
					source: "telegram",
					smsStatus: "skipped"
				});
				await store.recordJob(job);
				return job;
			}
			toman = hit.toman;
			source = "telegram";
			messageHash = await sha256hex(input.telegramMessageId ?? input.telegramText);
			if (quota.lastMessageHash === messageHash) {
				log(logs, "Duplicate Telegram message — skip");
				const job = finish({
					status: "skip",
					reason: "پیام تکراری تلگرام",
					source,
					priceToman: toman,
					smsStatus: "skipped"
				});
				await store.recordJob(job);
				return job;
			}
			log(logs, `Tether price detected: ${toman}`);
		} else {
			log(logs, "Fetching TGJU");
			const market = await fetchMarket({ bypassCache: true });
			if (!market.ok) {
				log(logs, "Market source unavailable");
				const job = finish({
					status: "error",
					reason: market.error,
					source: "tgju",
					smsStatus: "skipped"
				});
				await store.recordJob(job);
				return job;
			}
			toman = market.tether.toman;
			log(logs, `Tether price detected: ${toman}`);
			await store.recordTick({
				id: newId(),
				source: "tgju",
				symbol: "USDT",
				priceToman: toman,
				capturedAt: market.fetchedAt
			});
		}
		if (!isValidTomanPrice(toman)) {
			log(logs, "Price failed sanity check");
			const job = finish({
				status: "error",
				reason: "قیمت نامعتبر",
				source,
				priceToman: toman,
				smsStatus: "skipped"
			});
			await store.recordJob(job);
			return job;
		}
		const prev = engine.lastPriceToman ?? quota.lastPriceToman;
		const delta = prev == null ? null : toman - prev;
		const smsText = formatSms({
			toman,
			delta,
			time: parts.hhmm
		});
		let smsStatus = "dry-run";
		if (!input.deliver) {
			log(logs, "Dry-run — SMS not sent");
			smsStatus = "dry-run";
		} else if (!input.sms) {
			log(logs, "SMS not configured");
			smsStatus = "not-configured";
		} else {
			log(logs, "Sending SMS");
			const sent = await sendSms(input.sms, smsText);
			if (!sent.ok) {
				log(logs, "SMS API error");
				const job = finish({
					status: "error",
					reason: sent.error,
					source,
					priceToman: toman,
					deltaToman: delta,
					slot,
					smsStatus: "failed",
					smsText
				});
				await store.recordJob(job);
				return job;
			}
			smsStatus = "sent";
			log(logs, "SMS sent successfully");
			const nextSlots = slot && !slot.startsWith("manual-") ? [...quota.slotsSent, slot] : quota.slotsSent;
			await store.saveQuota({
				...quota,
				sentCount: quota.sentCount + 1,
				slotsSent: nextSlots,
				lastPriceToman: toman,
				lastMessageHash: messageHash ?? quota.lastMessageHash
			});
			await store.saveEngineState({
				lastPriceToman: toman,
				lastSentAt: startedAt
			});
		}
		if (smsStatus !== "sent") await store.saveEngineState({
			lastPriceToman: toman,
			lastSentAt: engine.lastSentAt
		});
		const job = finish({
			status: "ok",
			reason: smsStatus === "sent" ? "ارسال شد" : "آماده ارسال",
			source,
			priceToman: toman,
			deltaToman: delta,
			slot,
			smsStatus,
			smsText
		});
		await store.recordJob(job);
		return job;
	} catch {
		log(logs, "Unhandled error");
		const job = finish({
			status: "error",
			reason: "خطای غیرمنتظره — اجرای بعدی مستقل ادامه می‌یابد",
			smsStatus: "skipped"
		});
		try {
			await store.recordJob(job);
		} catch {}
		return job;
	}
}
var _0002_nerkh_default = "create table if not exists price_ticks (\n  id text primary key,\n  source text not null,\n  symbol text not null default 'USDT',\n  price_toman integer not null,\n  captured_at timestamptz not null default now()\n);\ncreate index if not exists price_ticks_captured_idx on price_ticks (captured_at desc);\n\ncreate table if not exists job_runs (\n  id text primary key,\n  started_at timestamptz not null default now(),\n  status text not null,\n  reason text,\n  source text,\n  price_toman integer,\n  delta_toman integer,\n  slot text,\n  sms_status text,\n  logs_json text not null default '[]'\n);\ncreate index if not exists job_runs_started_idx on job_runs (started_at desc);\n\ncreate table if not exists daily_quota (\n  day_key text primary key,\n  sent_count integer not null default 0,\n  slots_sent text not null default '[]',\n  last_price_toman integer,\n  last_message_hash text\n);\n\ncreate table if not exists engine_state (\n  id text primary key,\n  last_price_toman integer,\n  last_sent_at timestamptz,\n  updated_at timestamptz not null default now()\n);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_nerkh.sql": _0002_nerkh_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function emptyQuota(dayKey) {
	return {
		dayKey,
		sentCount: 0,
		slotsSent: [],
		lastPriceToman: null,
		lastMessageHash: null
	};
}
function parseLogs(raw) {
	try {
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function parseSlots(raw) {
	try {
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function jobFromRow(row) {
	return {
		id: row.id,
		startedAt: typeof row.started_at === "string" ? row.started_at : new Date(row.started_at).toISOString(),
		status: row.status,
		reason: row.reason,
		source: row.source,
		priceToman: row.price_toman,
		deltaToman: row.delta_toman,
		slot: row.slot,
		smsStatus: row.sms_status,
		logs: parseLogs(row.logs_json),
		smsText: null
	};
}
async function createPgStore() {
	const sql = await getSql();
	return {
		async getQuota(dayKey) {
			const row = (await sql`
        select day_key, sent_count, slots_sent, last_price_toman, last_message_hash
        from daily_quota where day_key = ${dayKey} limit 1
      `)[0];
			if (!row) return emptyQuota(dayKey);
			return {
				dayKey: row.day_key,
				sentCount: Number(row.sent_count) || 0,
				slotsSent: parseSlots(row.slots_sent),
				lastPriceToman: row.last_price_toman,
				lastMessageHash: row.last_message_hash
			};
		},
		async saveQuota(q) {
			await sql`
        insert into daily_quota (day_key, sent_count, slots_sent, last_price_toman, last_message_hash)
        values (
          ${q.dayKey},
          ${q.sentCount},
          ${JSON.stringify(q.slotsSent)},
          ${q.lastPriceToman},
          ${q.lastMessageHash}
        )
        on conflict (day_key) do update set
          sent_count = excluded.sent_count,
          slots_sent = excluded.slots_sent,
          last_price_toman = excluded.last_price_toman,
          last_message_hash = excluded.last_message_hash
      `;
		},
		async getEngineState() {
			const row = (await sql`
        select last_price_toman, last_sent_at from engine_state where id = ${"default"} limit 1
      `)[0];
			return {
				lastPriceToman: row?.last_price_toman ?? null,
				lastSentAt: row?.last_sent_at ?? null
			};
		},
		async saveEngineState(s) {
			await sql`
        insert into engine_state (id, last_price_toman, last_sent_at, updated_at)
        values (${"default"}, ${s.lastPriceToman}, ${s.lastSentAt}, now())
        on conflict (id) do update set
          last_price_toman = excluded.last_price_toman,
          last_sent_at = excluded.last_sent_at,
          updated_at = now()
      `;
		},
		async recordJob(job) {
			await sql`
        insert into job_runs (
          id, started_at, status, reason, source, price_toman, delta_toman, slot, sms_status, logs_json
        ) values (
          ${job.id},
          ${job.startedAt},
          ${job.status},
          ${job.reason},
          ${job.source},
          ${job.priceToman},
          ${job.deltaToman},
          ${job.slot},
          ${job.smsStatus},
          ${JSON.stringify(job.logs)}
        )
        on conflict (id) do nothing
      `;
			await sql`delete from job_runs where started_at < now() - interval '14 days'`;
		},
		async recordTick(tick) {
			await sql`
        insert into price_ticks (id, source, symbol, price_toman, captured_at)
        values (${tick.id}, ${tick.source}, ${tick.symbol}, ${tick.priceToman}, ${tick.capturedAt})
        on conflict (id) do nothing
      `;
			await sql`delete from price_ticks where captured_at < now() - interval '14 days'`;
		},
		async recentJobs(limit) {
			return (await sql`
        select id, started_at::text as started_at, status, reason, source,
               price_toman, delta_toman, slot, sms_status, logs_json
        from job_runs
        order by started_at desc
        limit ${limit}
      `).map(jobFromRow);
		},
		async recentTicks(limit) {
			return (await sql`
        select captured_at::text as captured_at, price_toman, source
        from price_ticks
        order by captured_at desc
        limit ${limit}
      `).map((r) => ({
				capturedAt: r.captured_at,
				priceToman: r.price_toman,
				source: r.source
			}));
		}
	};
}
//#endregion
export { extractTetherPrice as a, formatToman as c, pg_store_server_Dm1BeILm_exports as d, smsFromEnv as f, tehranParts as h, executeJob as i, nextSlots as l, tehranFaDate as m, __exportAll as n, fetchMarket as o, tehranClock as p, createPgStore as r, formatSms as s, DEFAULT_SLOTS as t, normalizeSlot as u };
