import { t as DEFAULT_SLOTS } from "./pg-store.server-Dm1BeILm.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Slot } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { o as cn } from "./router-B4EFIl9N.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-D6uC_Qvm.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color] duration-[var(--motion-fast,250ms)] ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "border border-border bg-transparent text-fg hover:bg-bg-subtle",
			ghost: "text-muted hover:bg-bg-subtle hover:text-fg",
			danger: "bg-down/15 text-down hover:bg-down/25"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var defaults = {
	priceSource: "tgju",
	smsProvider: "kavenegar",
	smsApiUrl: "",
	smsApiKey: "",
	smsTo: "",
	smsFrom: "",
	smsUsername: "",
	slots: [...DEFAULT_SLOTS],
	dailyLimit: 10,
	dryRun: true,
	telegramListen: false
};
var useSettings = create()(persist((set) => ({
	...defaults,
	set: (patch) => set(patch),
	reset: () => set(defaults)
}), { name: "nerkhresan-settings" }));
function settingsToSms(s) {
	if (!s.smsTo || !s.smsApiKey) return null;
	return {
		provider: s.smsProvider,
		apiUrl: s.smsApiUrl,
		apiKey: s.smsApiKey,
		to: s.smsTo,
		from: s.smsFrom || void 0,
		username: s.smsUsername || void 0
	};
}
//#endregion
export { settingsToSms as n, useSettings as r, Button as t };
