/**
 * The panel, served as one document from the Worker.
 *
 * Design brief: a rate board for one operator who mostly opens this on a
 * phone to answer three questions — what's the price, did the last send work,
 * and let me change one setting. So the prices are the hero, set large in
 * tabular figures on a dark navy board the way an exchange-office display is,
 * and everything else is quiet chrome underneath it.
 *
 * Nothing secret is rendered here. The page holds no API key and no password;
 * it talks to /api/* with the session cookie the browser attaches itself.
 */

const CSS = `
:root{
  --ink:#0E1A2B; --board:#152740; --raise:#1B3252; --line:#25415F;
  --text:#E8EFF7; --dim:#8DA6C2; --rise:#40C08A; --fall:#E4606A; --amber:#F2B233;
  --radius:10px;
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{
  margin:0; background:var(--ink); color:var(--text);
  font-family:Vazirmatn,system-ui,"Segoe UI",sans-serif;
  font-size:15px; line-height:1.65; direction:rtl;
}
.num{font-variant-numeric:tabular-nums lining-nums; letter-spacing:-.01em}
.wrap{max-width:720px; margin:0 auto; padding:20px 16px 56px}

header{display:flex; align-items:baseline; justify-content:space-between; gap:12px; margin-bottom:18px}
header h1{font-size:17px; font-weight:600; margin:0}
header .clock{color:var(--dim); font-size:13px}

/* ---- the board: the one place with visual weight ---- */
.board{background:var(--board); border:1px solid var(--line); border-radius:var(--radius); overflow:hidden}
.row{display:flex; align-items:center; gap:12px; padding:14px 16px; border-bottom:1px solid var(--line)}
.row:last-child{border-bottom:0}
.row .name{flex:1; min-width:0}
.row .name b{font-weight:500; display:block}
.row .name small{color:var(--dim); font-size:12px}
.row .price{font-size:26px; font-weight:600}
.row.down .price{color:var(--dim)}
.row .tag{font-size:11px; padding:2px 7px; border-radius:99px; border:1px solid var(--line); color:var(--dim); white-space:nowrap}
.row .tag.bad{color:var(--fall); border-color:var(--fall)}
.row .tag.out{color:var(--amber); border-color:var(--amber)}

.spread{display:flex; align-items:baseline; justify-content:space-between; padding:16px;
  background:var(--raise); border-top:1px solid var(--line)}
.spread .v{font-size:32px; font-weight:700; color:var(--amber)}
.spread span{color:var(--dim); font-size:13px}

/* ---- status strip ---- */
.strip{display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:1px;
  background:var(--line); border:1px solid var(--line); border-radius:var(--radius);
  overflow:hidden; margin-top:14px}
.strip div{background:var(--board); padding:11px 13px}
.strip small{display:block; color:var(--dim); font-size:12px}
.strip b{font-weight:500; font-size:14px}
.ok{color:var(--rise)} .bad{color:var(--fall)} .warn{color:var(--amber)}

/* ---- tabs ---- */
nav{display:flex; gap:4px; margin:22px 0 14px; border-bottom:1px solid var(--line)}
nav button{background:none; border:0; border-bottom:2px solid transparent; color:var(--dim);
  font:inherit; font-size:14px; padding:9px 13px; cursor:pointer; margin-bottom:-1px}
nav button[aria-selected=true]{color:var(--text); border-bottom-color:var(--amber)}
nav button:focus-visible{outline:2px solid var(--amber); outline-offset:2px}

section[hidden]{display:none}
fieldset{border:1px solid var(--line); border-radius:var(--radius); padding:14px 16px; margin:0 0 14px}
legend{padding:0 6px; color:var(--dim); font-size:13px}
label{display:block; margin:11px 0 5px; font-size:13px; color:var(--dim)}
input,select,textarea{width:100%; background:var(--ink); color:var(--text);
  border:1px solid var(--line); border-radius:8px; padding:9px 11px; font:inherit; font-size:14px}
input:focus,select:focus,textarea:focus{outline:2px solid var(--amber); outline-offset:1px; border-color:transparent}
textarea{min-height:92px; resize:vertical}
.inline{display:flex; gap:10px; align-items:center}
.inline input[type=checkbox]{width:auto}
.grid2{display:grid; grid-template-columns:1fr 1fr; gap:0 12px}
@media(max-width:480px){.grid2{grid-template-columns:1fr}}

button.act{background:var(--amber); color:#241905; border:0; border-radius:8px;
  padding:10px 18px; font:inherit; font-weight:600; font-size:14px; cursor:pointer}
button.act.ghost{background:none; color:var(--text); border:1px solid var(--line); font-weight:400}
button.act:disabled{opacity:.5; cursor:default}
.actions{display:flex; gap:8px; flex-wrap:wrap; margin-top:14px}

.chips{display:flex; flex-wrap:wrap; gap:7px; margin-top:8px}
.chip{display:flex; align-items:center; gap:6px; background:var(--board);
  border:1px solid var(--line); border-radius:99px; padding:5px 11px; font-size:13px}
.chip button{background:none;border:0;color:var(--dim);cursor:pointer;font:inherit;padding:0 2px}

.preview{background:var(--board); border:1px solid var(--line); border-radius:var(--radius);
  padding:13px 15px; white-space:pre-wrap; margin-top:10px; font-size:14px}
.meter{margin-top:8px; font-size:12px; color:var(--dim)}
.meter.over{color:var(--fall)}

table{width:100%; border-collapse:collapse; font-size:13px}
th,td{text-align:right; padding:8px 6px; border-bottom:1px solid var(--line)}
th{color:var(--dim); font-weight:500}

.toast{position:fixed; inset-inline:16px; bottom:16px; margin:0 auto; max-width:420px;
  background:var(--raise); border:1px solid var(--line); border-inline-start:3px solid var(--amber);
  border-radius:8px; padding:11px 14px; font-size:14px; opacity:0; transform:translateY(8px);
  transition:opacity .18s, transform .18s; pointer-events:none}
.toast.show{opacity:1; transform:none}
.toast.bad{border-inline-start-color:var(--fall)}
.toast.ok{border-inline-start-color:var(--rise)}
@media(prefers-reduced-motion:reduce){.toast{transition:none}}

.login{max-width:360px; margin:16vh auto; padding:0 16px}
.login p{color:var(--dim); font-size:13px}
`;

const LOGIN_HTML = (error) => `<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><title>ورود</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
<style>${CSS}</style></head><body>
<form class="login" method="POST" action="/login">
  <h1 style="font-size:18px;margin:0 0 4px">تابلوی نرخ تتر</h1>
  <p>برای دیدن قیمت‌ها و تنظیمات وارد شوید.</p>
  <label for="p">رمز عبور</label>
  <input id="p" name="password" type="password" autocomplete="current-password" required autofocus>
  ${error ? `<p class="bad" style="margin-top:10px">${error}</p>` : ""}
  <div class="actions"><button class="act" type="submit">ورود</button></div>
</form></body></html>`;

const PANEL_HTML = (csrf) => `<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><title>تابلوی نرخ تتر</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
<style>${CSS}</style></head><body>
<div class="wrap">
  <header>
    <h1>تابلوی نرخ تتر</h1>
    <span class="clock" id="clock">—</span>
  </header>

  <div class="board" id="board"><div class="row"><div class="name"><b>در حال دریافت…</b></div></div></div>
  <div class="spread"><span>اختلاف بیشترین و کمترین</span><span class="v num" id="spread">—</span></div>

  <div class="strip" id="strip"></div>

  <nav role="tablist">
    <button role="tab" id="t-dash" aria-selected="true" aria-controls="s-dash">خلاصه</button>
    <button role="tab" id="t-set" aria-selected="false" aria-controls="s-set">تنظیمات</button>
    <button role="tab" id="t-api" aria-selected="false" aria-controls="s-api">منابع قیمت</button>
    <button role="tab" id="t-log" aria-selected="false" aria-controls="s-log">تاریخچه</button>
  </nav>

  <section id="s-dash" role="tabpanel" aria-labelledby="t-dash">
    <fieldset><legend>پیام بعدی</legend>
      <div class="preview num" id="preview">—</div>
      <div class="meter" id="meter"></div>
      <div class="actions">
        <button class="act ghost" id="btn-refresh">تازه‌سازی قیمت‌ها</button>
        <button class="act ghost" id="btn-preview">ساخت پیش‌نمایش</button>
        <button class="act" id="btn-send">همین حالا بفرست</button>
      </div>
    </fieldset>
  </section>

  <section id="s-set" role="tabpanel" aria-labelledby="t-set" hidden>
    <fieldset><legend>ارسال</legend>
      <div class="inline"><input type="checkbox" id="autoSendEnabled"><label for="autoSendEnabled" style="margin:0">ارسال خودکار روشن باشد</label></div>
      <label for="slotInput">زمان‌های ارسال (تهران)</label>
      <div class="inline"><input id="slotInput" placeholder="۰۸:۳۰" inputmode="numeric">
        <button class="act ghost" id="btn-add-slot">افزودن</button></div>
      <div class="chips" id="slots"></div>
      <div class="grid2">
        <div><label for="dailySmsLimit">سقف پیامک روزانه</label><input id="dailySmsLimit" type="number" min="1" max="10"></div>
        <div><label for="slotWindowMin">پنجره جبران (دقیقه)</label><input id="slotWindowMin" type="number" min="1" max="120"></div>
      </div>
      <label for="smsLineNumber">خط ارسال SMS.ir</label><input id="smsLineNumber" inputmode="numeric">
      <p class="meter">شماره گیرنده و کلید SMS.ir در Cloudflare Secrets نگه‌داری می‌شوند و از این صفحه قابل خواندن نیستند.</p>
    </fieldset>

    <fieldset><legend>قالب پیام</legend>
      <textarea id="template"></textarea>
      <div class="meter" id="tplMeter"></div>
      <p class="meter">جای‌گذارها: {نام منبع} مثل {nobitex} • {consensus} • {spread} • {delta} • {high} • {low} • {time} • {date}</p>
      <div class="inline" style="margin-top:8px"><input type="checkbox" id="persianDigits"><label for="persianDigits" style="margin:0">ارقام فارسی</label></div>
    </fieldset>

    <fieldset><legend>اعتبارسنجی قیمت</legend>
      <div class="grid2">
        <div><label for="minSourcesRequired">حداقل منابع سالم</label><input id="minSourcesRequired" type="number" min="1" max="10"></div>
        <div><label for="maxDeviationPct">حذف منبع پرت (٪ از میانه)</label><input id="maxDeviationPct" type="number" step="0.1"></div>
        <div><label for="maxJumpPct">سقف جهش نسبت به قبل (٪)</label><input id="maxJumpPct" type="number"></div>
        <div><label for="primarySource">منبع اصلی</label><select id="primarySource"></select></div>
        <div><label for="minToman">حداقل قیمت منطقی</label><input id="minToman" type="number"></div>
        <div><label for="maxToman">حداکثر قیمت منطقی</label><input id="maxToman" type="number"></div>
      </div>
    </fieldset>
    <div class="actions"><button class="act" id="btn-save">ذخیره تنظیمات</button></div>
  </section>

  <section id="s-api" role="tabpanel" aria-labelledby="t-api" hidden>
    <fieldset><legend>منابع فعال</legend><div class="chips" id="sourceToggles"></div></fieldset>
    <fieldset><legend>افزودن منبع</legend>
      <div class="grid2">
        <div><label for="c-id">شناسه</label><input id="c-id" placeholder="wallex"></div>
        <div><label for="c-label">نام نمایشی</label><input id="c-label" placeholder="والکس"></div>
      </div>
      <label for="c-url">آدرس</label><input id="c-url" placeholder="https://api.wallex.ir/v1/markets" dir="ltr">
      <div class="grid2">
        <div><label for="c-path">مسیر مقدار در پاسخ</label><input id="c-path" placeholder="result.symbols.USDTTMN.stats.lastPrice" dir="ltr"></div>
        <div><label for="c-unit">واحد</label><select id="c-unit"><option value="auto">تشخیص خودکار</option><option value="toman">تومان</option><option value="rial">ریال</option></select></div>
      </div>
      <p class="meter">فقط https و فقط دامنه‌های مجاز. مسیر یک آدرس ساده در JSON است؛ کد اجرا نمی‌شود.</p>
      <div class="actions">
        <button class="act ghost" id="btn-test">آزمایش</button>
        <button class="act" id="btn-add-api">افزودن</button>
      </div>
      <div class="preview" id="testOut" hidden></div>
    </fieldset>
    <fieldset><legend>سلامت منابع (۲۴ ساعت)</legend><table id="health"><tbody></tbody></table></fieldset>
  </section>

  <section id="s-log" role="tabpanel" aria-labelledby="t-log" hidden>
    <table><thead><tr><th>زمان</th><th>نوبت</th><th>وضعیت</th><th>قیمت</th><th>توضیح</th></tr></thead>
    <tbody id="runs"></tbody></table>
    <div class="actions"><button class="act ghost" id="btn-logout">خروج</button></div>
  </section>
</div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>

<script>
const CSRF = ${JSON.stringify(csrf)};
const $ = (id) => document.getElementById(id);
let settings = null, registry = [], lastQuotes = null;

const fmt = (n) => n == null ? "—" : Math.round(n).toLocaleString("en-US");

function toast(msg, kind) {
  const el = $("toast");
  el.textContent = msg; el.className = "toast show " + (kind || "");
  clearTimeout(el._t); el._t = setTimeout(() => el.className = "toast " + (kind || ""), 3200);
}

async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", "X-CSRF": CSRF, ...(opts.headers || {}) },
  });
  if (res.status === 401) { location.href = "/"; return null; }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || ("خطای " + res.status));
  return body;
}

// ---- rendering ----
function drawBoard(q) {
  lastQuotes = q;
  const board = $("board");
  board.innerHTML = "";
  for (const r of q.results) {
    const row = document.createElement("div");
    row.className = "row" + (r.ok ? "" : " down");
    const tag = !r.ok ? '<span class="tag bad">خطا</span>'
      : r.outlier ? '<span class="tag out">پرت</span>'
      : '<span class="tag">' + r.ms + 'ms</span>';
    row.innerHTML = '<div class="name"><b>' + r.label + '</b><small>' + (r.ok ? r.id : r.error) + '</small></div>'
      + tag + '<div class="price num">' + (r.ok ? fmt(r.toman) : "—") + '</div>';
    board.appendChild(row);
  }
  $("spread").textContent = q.ok ? fmt(q.spread) : "—";
  $("clock").textContent = q.tehran + " تهران";
}

function drawStrip(s) {
  $("strip").innerHTML = [
    ["ارسال خودکار", s.autoSendEnabled ? '<b class="ok">روشن</b>' : '<b class="warn">خاموش</b>'],
    ["امروز", '<b class="num">' + s.sentToday + " از " + s.dailySmsLimit + "</b>"],
    ["نوبت بعدی", '<b class="num">' + (s.nextSlot || "—") + "</b>"],
    ["آخرین ارسال موفق", '<b class="num">' + (s.lastSent || "هنوز هیچ") + "</b>"],
    ["آخرین خطا", s.lastError ? '<b class="bad">' + s.lastError + "</b>" : "<b>ندارد</b>"],
  ].map(([k, v]) => "<div><small>" + k + "</small>" + v + "</div>").join("");
}

function drawSettings() {
  for (const id of ["dailySmsLimit","slotWindowMin","smsLineNumber","template","minSourcesRequired",
                    "maxDeviationPct","maxJumpPct","minToman","maxToman"]) $(id).value = settings[id];
  $("autoSendEnabled").checked = settings.autoSendEnabled;
  $("persianDigits").checked = settings.persianDigits;
  drawSlots();
  $("primarySource").innerHTML = registry.map(a =>
    '<option value="' + a.id + '"' + (a.id === settings.primarySource ? " selected" : "") + ">" + a.label + "</option>").join("");
  $("sourceToggles").innerHTML = registry.map(a => {
    const on = settings.activeSources.includes(a.id);
    return '<span class="chip"><input type="checkbox" data-src="' + a.id + '"' + (on ? " checked" : "") + "> " + a.label + "</span>";
  }).join("");
  updateTplMeter();
}

function drawSlots() {
  $("slots").innerHTML = settings.slots.map(s =>
    '<span class="chip num">' + s + '<button data-slot="' + s + '" aria-label="حذف ' + s + '">×</button></span>').join("");
}

function updateTplMeter() {
  const t = $("template").value;
  const units = [...t].some(c => c.charCodeAt(0) > 127) ? t.length : t.length;
  const ucs2 = [...t].some(c => c.charCodeAt(0) > 127);
  const per = ucs2 ? (units <= 70 ? 70 : 67) : (units <= 160 ? 160 : 153);
  const segs = Math.ceil(units / per) || 1;
  const m = $("tplMeter");
  m.textContent = units + " کاراکتر • " + (ucs2 ? "UCS-2" : "GSM-7") + " • " + segs + " بخش (قالب خام، بدون اعداد)";
  m.className = "meter" + (segs > 1 ? " over" : "");
}

// ---- actions ----
async function refresh(force) {
  try {
    const data = await api("/api/state" + (force ? "?refresh=1" : ""));
    if (!data) return;
    settings = data.settings; registry = data.registry;
    drawBoard(data.quotes); drawStrip(data.status); drawSettings();
    $("health").querySelector("tbody").innerHTML = data.health.map(h =>
      "<tr><td>" + h.source_id + "</td><td class='num'>" + Math.round(100 * h.ok_count / h.total) + "٪</td><td class='num'>" + (h.avg_ms || 0) + "ms</td></tr>").join("")
      || "<tr><td>هنوز داده‌ای ثبت نشده</td></tr>";
    $("runs").innerHTML = data.runs.map(r =>
      "<tr><td class='num'>" + r.started_at.slice(5, 16).replace("T", " ") + "</td><td class='num'>" + (r.slot || "—") +
      "</td><td>" + r.status + "</td><td class='num'>" + fmt(r.consensus) + "</td><td>" + (r.reason || "") + "</td></tr>").join("")
      || "<tr><td colspan='5'>هنوز اجرایی ثبت نشده</td></tr>";
  } catch (e) { toast(e.message, "bad"); }
}

$("btn-refresh").onclick = () => refresh(true);

$("btn-preview").onclick = async () => {
  try {
    const r = await api("/api/preview", { method: "POST" });
    $("preview").textContent = r.smsText || r.reason;
    $("meter").textContent = r.segment
      ? r.segment.units + " کاراکتر " + r.segment.encoding + " • " + r.segment.segments + " بخش • " + r.segment.remaining + " کاراکتر باقی"
      : "";
    $("meter").className = "meter" + (r.segment && r.segment.segments > 1 ? " over" : "");
  } catch (e) { toast(e.message, "bad"); }
};

$("btn-send").onclick = async () => {
  if (!confirm("یک پیامک واقعی ارسال شود؟ از سهمیه امروز کم می‌شود.")) return;
  try {
    const r = await api("/api/send", { method: "POST" });
    toast(r.status === "sent" ? "ارسال شد" : r.reason, r.status === "sent" ? "ok" : "bad");
    refresh();
  } catch (e) { toast(e.message, "bad"); }
};

$("btn-add-slot").onclick = () => {
  const v = $("slotInput").value.trim();
  if (!/^([01]?\\d|2[0-3]):[0-5]\\d$/.test(v)) return toast("زمان باید به شکل HH:MM باشد", "bad");
  const padded = v.padStart(5, "0");
  if (!settings.slots.includes(padded)) { settings.slots.push(padded); settings.slots.sort(); drawSlots(); }
  $("slotInput").value = "";
};
$("slots").onclick = (e) => {
  const s = e.target.dataset.slot;
  if (!s) return;
  settings.slots = settings.slots.filter(x => x !== s); drawSlots();
};
$("template").oninput = updateTplMeter;

$("btn-save").onclick = async () => {
  const active = [...document.querySelectorAll("[data-src]")].filter(c => c.checked).map(c => c.dataset.src);
  const payload = {
    ...settings, activeSources: active,
    autoSendEnabled: $("autoSendEnabled").checked, persianDigits: $("persianDigits").checked,
    primarySource: $("primarySource").value, template: $("template").value,
    smsLineNumber: $("smsLineNumber").value,
  };
  for (const id of ["dailySmsLimit","slotWindowMin","minSourcesRequired","maxDeviationPct","maxJumpPct","minToman","maxToman"])
    payload[id] = Number($(id).value);
  try {
    const r = await api("/api/settings", { method: "PUT", body: JSON.stringify(payload) });
    settings = r.settings; toast("ذخیره شد", "ok"); refresh();
  } catch (e) { toast(e.message, "bad"); }
};

function customPayload() {
  return { id: $("c-id").value.trim(), label: $("c-label").value.trim(),
           url: $("c-url").value.trim(), path: $("c-path").value.trim(), unit: $("c-unit").value };
}

$("btn-test").onclick = async () => {
  const out = $("testOut"); out.hidden = false; out.textContent = "در حال آزمایش…";
  try {
    const r = await api("/api/sources/test", { method: "POST", body: JSON.stringify(customPayload()) });
    out.textContent = r.ok ? "موفق — مقدار استخراج‌شده: " + fmt(r.toman) + " تومان (" + r.ms + "ms)" : "ناموفق — " + r.error;
  } catch (e) { out.textContent = "ناموفق — " + e.message; }
};

$("btn-add-api").onclick = async () => {
  try {
    const r = await api("/api/sources", { method: "POST", body: JSON.stringify(customPayload()) });
    settings = r.settings; toast("منبع اضافه شد", "ok"); refresh();
  } catch (e) { toast(e.message, "bad"); }
};

$("btn-logout").onclick = async () => { await api("/logout", { method: "POST" }); location.href = "/"; };

// ---- tabs ----
document.querySelectorAll('[role=tab]').forEach(tab => {
  tab.onclick = () => {
    document.querySelectorAll('[role=tab]').forEach(t => {
      const on = t === tab;
      t.setAttribute("aria-selected", String(on));
      document.getElementById(t.getAttribute("aria-controls")).hidden = !on;
    });
  };
});

refresh();
setInterval(() => { if (!document.hidden) refresh(); }, 60000);
</script></body></html>`;

export { LOGIN_HTML, PANEL_HTML };
