import { allAdapters, runAdapter } from "./adapters.js";

/**
 * Fetch every active source in parallel, then decide what to believe.
 *
 * The validation ladder — each step exists because of a specific failure:
 *  1. range check      → an endpoint returned 1 or 9e9 after a schema change
 *  2. median consensus → one exchange lags or shows a stale cached price
 *  3. deviation filter → that lagging source is dropped, not averaged in
 *  4. quorum           → with fewer than N agreeing sources we send nothing
 *  5. jump guard       → the consensus itself moved impossibly vs last time
 *
 * A single bad source can therefore never produce an SMS on its own.
 */

export function median(values) {
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : Math.round((s[mid - 1] + s[mid]) / 2);
}

export async function gatherQuotes(settings, { only } = {}) {
  const registry = allAdapters(settings);
  const wanted = only || settings.activeSources;
  const selected = wanted.map((id) => registry.find((a) => a.id === id)).filter(Boolean);

  const results = await Promise.all(selected.map((a) => runAdapter(a)));

  // 1. range check
  for (const r of results) {
    if (r.ok && (r.toman < settings.minToman || r.toman > settings.maxToman)) {
      r.ok = false;
      r.error = `خارج از بازه منطقی (${r.toman})`;
      delete r.toman;
    }
  }

  const healthy = results.filter((r) => r.ok);
  if (healthy.length === 0) {
    return { ok: false, reason: "هیچ منبعی پاسخ معتبر نداد", results, consensus: null, accepted: [] };
  }

  // 2 + 3. median then deviation filter
  const med = median(healthy.map((r) => r.toman));
  const accepted = [];
  for (const r of healthy) {
    const dev = (Math.abs(r.toman - med) / med) * 100;
    r.deviationPct = Number(dev.toFixed(2));
    if (dev > settings.maxDeviationPct) {
      r.outlier = true;
    } else {
      accepted.push(r);
    }
  }

  // 4. quorum — but one source is allowed if that's all the operator configured
  const required = Math.min(settings.minSourcesRequired, settings.activeSources.length);
  if (accepted.length < required) {
    return {
      ok: false,
      reason: `فقط ${accepted.length} منبع سالم بود (حداقل ${required} لازم است)`,
      results,
      consensus: null,
      accepted,
    };
  }

  const consensus = median(accepted.map((r) => r.toman));
  const prices = accepted.map((r) => r.toman);
  const spread = Math.max(...prices) - Math.min(...prices);

  return {
    ok: true,
    reason: null,
    results,
    accepted,
    consensus,
    spread,
    high: accepted.reduce((a, b) => (b.toman > a.toman ? b : a)),
    low: accepted.reduce((a, b) => (b.toman < a.toman ? b : a)),
    at: new Date().toISOString(),
  };
}

/** 5. jump guard, applied against the last value we actually accepted. */
export function jumpExceeded(consensus, previous, maxJumpPct) {
  if (previous == null) return null;
  const pct = (Math.abs(consensus - previous) / previous) * 100;
  return pct > maxJumpPct ? pct : null;
}
