/**
 * Authentication.
 *
 * Design notes (this replaces "password in the URL"):
 *  - The password is never stored. ADMIN_PASSWORD_HASH holds
 *    `pbkdf2$<iterations>$<saltB64>$<hashB64>`. Verification is constant-time.
 *  - A successful login mints a session token = <payloadB64>.<hmacB64>, signed
 *    with SESSION_SECRET. Nothing in the cookie is secret on its own: if the
 *    signature does not verify, the payload is meaningless.
 *  - Cookie is HttpOnly (JS can't read it), Secure, SameSite=Strict, Path=/.
 *  - CSRF: SameSite=Strict already blocks cross-site form posts, but we also
 *    require an X-CSRF header equal to the session's csrf claim on every
 *    mutating request. Two independent checks, because one of them is a
 *    browser behaviour we don't control.
 *  - Login attempts are throttled per-IP in KV. Without this, an 8-character
 *    password is brute-forceable against a Worker that answers in 20ms.
 */

const enc = new TextEncoder();

const b64url = (buf) =>
  btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

const fromB64url = (s) => {
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64 + "=".repeat((4 - (b64.length % 4)) % 4));
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
};

function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** Produce a hash string to put in the ADMIN_PASSWORD_HASH secret. */
export async function hashPassword(password, iterations = 150_000) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const bits = await derive(password, salt, iterations);
  return `pbkdf2$${iterations}$${b64url(salt)}$${b64url(bits)}`;
}

async function derive(password, salt, iterations) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  return crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, key, 256);
}

export async function verifyPassword(password, stored) {
  if (!stored || !password) return false;
  const [scheme, iterRaw, saltRaw, hashRaw] = stored.split("$");
  if (scheme !== "pbkdf2") return false;
  const iterations = Number(iterRaw);
  if (!Number.isFinite(iterations) || iterations < 10_000) return false;
  const bits = await derive(password, fromB64url(saltRaw), iterations);
  return timingSafeEqual(b64url(bits), hashRaw);
}

// --- session token ---------------------------------------------------------

async function hmacKey(secret) {
  return crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
}

export async function mintSession(secret, ttlSeconds = 60 * 60 * 8) {
  const payload = {
    sub: "admin",
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + ttlSeconds,
    csrf: b64url(crypto.getRandomValues(new Uint8Array(16))),
  };
  const body = b64url(enc.encode(JSON.stringify(payload)));
  const sig = b64url(await crypto.subtle.sign("HMAC", await hmacKey(secret), enc.encode(body)));
  return { token: `${body}.${sig}`, payload };
}

export async function readSession(secret, token) {
  if (!token || !secret) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = b64url(await crypto.subtle.sign("HMAC", await hmacKey(secret), enc.encode(body)));
  if (!timingSafeEqual(sig, expected)) return null;
  try {
    const payload = JSON.parse(new TextDecoder().decode(fromB64url(body)));
    if (typeof payload.exp !== "number" || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

export const COOKIE_NAME = "sid";

export function sessionCookie(token, maxAge) {
  return `${COOKIE_NAME}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${maxAge}`;
}

export function clearCookie() {
  return `${COOKIE_NAME}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`;
}

export function readCookie(req, name = COOKIE_NAME) {
  const raw = req.headers.get("cookie") || "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === name) return v.join("=");
  }
  return null;
}

// --- login throttle --------------------------------------------------------

const MAX_ATTEMPTS = 8;
const WINDOW_SECONDS = 900; // 15 minutes

export async function throttleCheck(kv, ip) {
  const key = `login:${ip}`;
  const n = Number((await kv.get(key)) || 0);
  return { blocked: n >= MAX_ATTEMPTS, attempts: n, key };
}

export async function throttleFail(kv, key, attempts) {
  await kv.put(key, String(attempts + 1), { expirationTtl: WINDOW_SECONDS });
}

export async function throttleReset(kv, key) {
  await kv.delete(key);
}
