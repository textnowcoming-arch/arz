-- D1 holds everything append-only and queryable. KV holds config only.
-- Rationale: KV has no range queries, no aggregation, and eventual consistency
-- on writes — all three are fatal for history and for a run log you need to
-- trust when debugging why 20:15 did not send.

CREATE TABLE IF NOT EXISTS price_ticks (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  captured_at TEXT NOT NULL,          -- ISO8601 UTC
  source_id  TEXT NOT NULL,
  toman      INTEGER NOT NULL,
  latency_ms INTEGER,
  ok         INTEGER NOT NULL DEFAULT 1,
  error      TEXT
);
CREATE INDEX IF NOT EXISTS idx_ticks_time   ON price_ticks (captured_at DESC);
CREATE INDEX IF NOT EXISTS idx_ticks_source ON price_ticks (source_id, captured_at DESC);

CREATE TABLE IF NOT EXISTS runs (
  id          TEXT PRIMARY KEY,        -- uuid
  started_at  TEXT NOT NULL,
  day_key     TEXT NOT NULL,           -- Tehran YYYY-MM-DD, the unit the cap counts over
  slot        TEXT,
  trigger     TEXT NOT NULL,           -- cron | manual | preview
  status      TEXT NOT NULL,           -- sent | skipped | failed | preview
  reason      TEXT,
  consensus   INTEGER,
  spread      INTEGER,
  delta       INTEGER,
  sources_ok  INTEGER,
  sources_total INTEGER,
  sms_segments INTEGER,
  sms_text    TEXT,
  duration_ms INTEGER
);
CREATE INDEX IF NOT EXISTS idx_runs_time ON runs (started_at DESC);
CREATE INDEX IF NOT EXISTS idx_runs_day  ON runs (day_key, status);

CREATE TABLE IF NOT EXISTS logs (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id  TEXT,
  at      TEXT NOT NULL,
  level   TEXT NOT NULL,               -- info | warn | error
  message TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_logs_run ON logs (run_id, id);
