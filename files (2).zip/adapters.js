/**
 * Price adapters.
 *
 * Adding an exchange is one object in BUILTIN — id, label, url, and a `pick`
 * that turns the parsed response into a toman number. Nothing else in the
 * system needs to change: settings.activeSources refers to ids, the panel
 * lists whatever is registered, the message template resolves {<id>}.
 *
 * Operator-defined adapters (added from the panel, stored in KV) run through
 * `runCustom`, which is deliberately much more restricted than the built-ins:
 *
 *   - host must be on ALLOWED_HOSTS. An admin panel that will fetch any URL
 *     you type is a server-side request forgery tool. Cloudflare Workers can
 *     reach internal-ish endpoints and metadata services on some networks, and
 *     a stolen session should not become "read arbitrary URLs from my IP".
 *   - https only, no redirects followed to a different host.
 *   - response capped, timeout enforced.
 *   - extraction is a literal dot/bracket path, evaluated by walking the
 *     object. No eval, no Function, no template execution. Ever.
 *   - no secret interpolation. Custom adapters are for public price endpoints.
 */

export const ALLOWED_HOSTS = [
  "api.nobitex.ir",
  "api.bitpin.market",
  "api.bitpin.org",
  "api.wallex.ir",
  "api.ramzinex.com",
  "api.exir.io",
  "api.tabdeal.org",
  "call1.tgju.org",
  "call3.tgju.org",
  "call5.tgju.org",
  "www.tgju.org",
];

const UA = "usdt-panel/1.0";
const MAX_BYTES = 256 * 1024;

/** Rial → toman when the figure is clearly rial-scale. */
export const rialToToman = (n) => (n >= 1_000_000 ? Math.round(n / 10) : Math.round(n));

const num = (v) => {
  if (v == null) return null;
  const n = Number(String(v).replace(/[,\s]/g, ""));
  return Number.isFinite(n) && n > 0 ? n : null;
};

/** Walk a literal path like `stats.usdt-rls.bestSell` or `results[0].price`. */
export function pickPath(obj, path) {
  if (!path) return null;
  let cur = obj;
  for (const seg of String(path).split(/[.[\]]+/).filter(Boolean)) {
    if (cur == null || typeof cur !== "object") return null;
    cur = cur[seg];
  }
  return cur;
}

async function getJson(url, { timeoutMs = 8000, headers = {} } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      redirect: "follow",
      headers: { Accept: "application/json", "User-Agent": UA, ...headers },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = (await res.text()).slice(0, MAX_BYTES);
    return JSON.parse(text);
  } finally {
    clearTimeout(timer);
  }
}

// --- built-in adapters -----------------------------------------------------

export const BUILTIN = [
  {
    id: "nobitex",
    label: "نوبیتکس",
    kind: "exchange",
    url: "https://api.nobitex.ir/v2/orderbook?symbol=USDTIRT",
    docs: "https://apidocs.nobitex.ir",
    /** Nobitex quotes IRT pairs in rial. lastTradePrice is the live number. */
    pick: (j) => {
      const v = num(j?.lastTradePrice) ?? num(j?.asks?.[0]?.[0]) ?? num(j?.bids?.[0]?.[0]);
      return v == null ? null : rialToToman(v);
    },
    fallback: {
      url: "https://api.nobitex.ir/market/stats?srcCurrency=usdt&dstCurrency=rls",
      pick: (j) => {
        const s = j?.stats?.["usdt-rls"];
        const v = num(s?.latest) ?? num(s?.bestSell) ?? num(s?.bestBuy);
        return v == null ? null : rialToToman(v);
      },
    },
  },
  {
    id: "bitpin",
    label: "بیت‌پین",
    kind: "exchange",
    // Bitpin has moved its public base URL before (bitpin.org → bitpin.market)
    // and does not publish a stable public doc. Both candidates are tried; use
    // the panel's API tester to pin the working one if they change it again.
    url: "https://api.bitpin.market/api/v1/mkt/tickers/",
    pick: (j) => pickTickerUsdt(j),
    fallback: {
      url: "https://api.bitpin.org/v1/mkt/tickers/",
      pick: (j) => pickTickerUsdt(j),
    },
  },
  {
    id: "tgju",
    label: "TGJU",
    kind: "index",
    url: "https://call5.tgju.org/ajax.json",
    pick: (j) => {
      const v = num(j?.current?.["crypto-tether-irr"]?.p);
      return v == null ? null : rialToToman(v);
    },
    fallback: {
      url: "https://call3.tgju.org/ajax.json",
      pick: (j) => {
        const v = num(j?.current?.["crypto-tether-irr"]?.p);
        return v == null ? null : rialToToman(v);
      },
    },
  },
];

/** Bitpin ticker payloads have been both an array and a keyed object. Handle both. */
function pickTickerUsdt(j) {
  const rows = Array.isArray(j) ? j : Array.isArray(j?.results) ? j.results : Object.values(j || {});
  for (const row of rows) {
    if (!row || typeof row !== "object") continue;
    const symbol = String(row.symbol ?? row.code ?? row.market ?? "").toUpperCase();
    if (symbol === "USDT_IRT" || symbol === "USDTIRT" || symbol === "USDT-IRT") {
      const v = num(row.price) ?? num(row.last) ?? num(row.close);
      return v == null ? null : rialToToman(v);
    }
  }
  return null;
}

export const builtinIds = () => BUILTIN.map((a) => a.id);

// --- running ---------------------------------------------------------------

/**
 * @returns {Promise<{id,label,ok,toman?,error?,ms,url}>}
 */
export async function runAdapter(adapter, { timeoutMs = 8000 } = {}) {
  const started = Date.now();
  const attempts = [{ url: adapter.url, pick: adapter.pick }];
  if (adapter.fallback) attempts.push(adapter.fallback);

  let lastError = "unknown";
  for (const attempt of attempts) {
    try {
      const json = await getJson(attempt.url, { timeoutMs, headers: adapter.headers });
      const toman = attempt.pick(json);
      if (toman == null || !Number.isFinite(toman)) throw new Error("مقدار قیمت در پاسخ پیدا نشد");
      return { id: adapter.id, label: adapter.label, ok: true, toman, ms: Date.now() - started, url: attempt.url };
    } catch (err) {
      lastError = err?.name === "AbortError" ? "timeout" : String(err?.message || err).slice(0, 120);
    }
  }
  return { id: adapter.id, label: adapter.label, ok: false, error: lastError, ms: Date.now() - started, url: adapter.url };
}

/** Turn an operator-defined record from KV into a runnable adapter, or reject it. */
export function compileCustom(def) {
  const errors = [];
  if (!def?.id || !/^[a-z0-9_-]{2,24}$/.test(def.id)) errors.push("شناسه نامعتبر (a-z0-9_- و ۲ تا ۲۴ کاراکتر)");
  if (builtinIds().includes(def?.id)) errors.push("این شناسه رزرو شده است");

  let url;
  try {
    url = new URL(def.url);
  } catch {
    errors.push("URL نامعتبر");
  }
  if (url) {
    if (url.protocol !== "https:") errors.push("فقط https مجاز است");
    if (!ALLOWED_HOSTS.includes(url.hostname)) {
      errors.push(`دامنه ${url.hostname} در لیست مجاز نیست — اول آن را به ALLOWED_HOSTS اضافه کنید`);
    }
  }
  if (!def?.path) errors.push("مسیر استخراج مقدار (path) لازم است");
  if (def?.headers && typeof def.headers !== "object") errors.push("هدرها باید شیء باشند");

  if (errors.length) return { ok: false, errors };

  const unit = def.unit === "rial" ? "rial" : def.unit === "toman" ? "toman" : "auto";
  return {
    ok: true,
    adapter: {
      id: def.id,
      label: def.label || def.id,
      kind: "custom",
      url: def.url,
      headers: def.headers || {},
      pick: (j) => {
        const v = num(pickPath(j, def.path));
        if (v == null) return null;
        if (unit === "rial") return Math.round(v / 10);
        if (unit === "toman") return Math.round(v);
        return rialToToman(v);
      },
    },
  };
}

/** All adapters the system currently knows about, built-in + operator-defined. */
export function allAdapters(settings) {
  const custom = [];
  for (const def of settings.customSources || []) {
    if (def.enabled === false) continue;
    const compiled = compileCustom(def);
    if (compiled.ok) custom.push(compiled.adapter);
  }
  return [...BUILTIN, ...custom];
}
